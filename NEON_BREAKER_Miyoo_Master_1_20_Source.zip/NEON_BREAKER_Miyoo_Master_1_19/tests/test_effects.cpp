#include "effects.hpp"
#include <cassert>
int main(){
 using namespace nb;
 auto p=particleBurst(20,30,24,{255,120,60},1234);
 assert(p.size()==24);
 assert(p.front().x==20 && p.front().y==30);
 assert(p.front().life>0 && p.front().maxLife>=p.front().life);
 assert(particleBrightness(p.front())>0);
 auto same=particleBurst(20,30,24,{255,120,60},1234);
 assert(p[0].vx==same[0].vx && p[0].vy==same[0].vy);
 updateParticles(p,1.0f);
 assert(p.size()==24 && p[0].y!=30);
 auto many=particleBurst(0,0,999,{1,2,3}); assert(many.size()==48);
 for(int i=0;i<80;++i) updateParticles(p,1.0f);
 assert(p.empty());
 return 0;
}
