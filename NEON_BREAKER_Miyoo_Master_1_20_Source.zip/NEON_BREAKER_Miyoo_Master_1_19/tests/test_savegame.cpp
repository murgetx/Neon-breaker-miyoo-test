#include "savegame.hpp"
#include <cassert>
#include <cstdio>
#include <cmath>
#include <fstream>
#include <limits>
int main(){
 nb::GameSession a; a.beginLevel(37); a.score=9876; a.levelScore=123; a.lives=2; a.campaign.values[0]=4; a.campaign.seen[2]=true; a.layout.bricks[0].hp=0; a.boss.hp=7; a.boss.phase=2; a.boss.shots.push_back({123,234,1.5,2.5,4}); a.falling.push_back({150,220,1.8,'W',false}); a.powers.extraBalls.push_back({180,400,2,-5,false}); a.powers.shots.push_back({190,500,2,8}); a.rngState=987654321;
 assert(nb::saveGame(a,"test_save.tmp")); nb::GameSession b; assert(nb::loadGame(b,"test_save.tmp"));
 assert(b.level==37 && b.score==9876 && b.levelScore==123 && b.lives==2);
 assert(b.campaign.values[0]==4 && b.campaign.seen[2]);
 assert(b.layout.bricks[0].hp==0 && b.boss.hp==7 && b.boss.phase==2);
 assert(b.boss.shots.size()==1 && b.boss.shots[0].x==123); assert(b.falling.size()==1 && b.falling[0].type=='W'); assert(b.powers.extraBalls.size()==1); assert(b.powers.shots.size()==1 && b.rngState==987654321); // Atomic replacement keeps the previous generation as a rollback copy.
 nb::GameSession newer=a; newer.score=12345;
 assert(nb::saveGame(newer,"test_save.tmp"));
 std::ifstream backup("test_save.tmp.bak"); assert(backup.good()); backup.close();
 // Invalid runtime data must not overwrite the valid save.
 newer.ball.x=std::numeric_limits<double>::quiet_NaN();
 assert(!nb::saveGame(newer,"test_save.tmp"));
 nb::GameSession latest; assert(nb::loadGame(latest,"test_save.tmp"));
 assert(latest.score==12345);
 std::remove("test_save.tmp"); std::remove("test_save.tmp.bak"); std::remove("test_save.tmp.tmp");
}
