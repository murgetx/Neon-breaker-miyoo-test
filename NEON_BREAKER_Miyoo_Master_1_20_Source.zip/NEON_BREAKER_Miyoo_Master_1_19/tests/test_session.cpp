#include "game_session.hpp"
#include <cassert>
int main(){ nb::GameSession g; g.beginLevel(1); assert(g.layout.level==1); assert(!g.layout.bricks.empty()); auto r=g.tick(200); (void)r; g.beginLevel(100); assert(g.layout.level==100); return 0; }
