#include "game_session.hpp"
#include <cassert>
int main(){nb::GameSession g;g.beginLevel(1);g.powers.gunTimer=60;for(int i=0;i<29;++i)g.tick(200);assert(!g.powers.shots.empty());g.powers.shots.clear();g.powers.laserTimer=60;for(int i=0;i<19;++i)g.tick(200);assert(g.powers.shots.size()>=2);return 0;}
