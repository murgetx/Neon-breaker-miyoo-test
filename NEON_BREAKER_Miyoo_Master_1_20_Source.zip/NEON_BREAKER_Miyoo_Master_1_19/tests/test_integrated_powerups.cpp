#include "game_session.hpp"
#include <cassert>
int main(){
 nb::GameSession g; g.beginLevel(1);
 assert(g.lives==3 && g.paddle.w==70);
 nb::PowerBall b{200,610,2,-5.8,false};
 nb::collectPower(g.powers,b,'W'); g.paddle.w=g.powers.paddleWidth;
 assert(g.paddle.w==112 && g.powers.wideTimer==720);
 nb::collectPower(g.powers,b,'T'); assert(!g.powers.extraBalls.empty());
 nb::collectPower(g.powers,b,'B'); assert(g.powers.lives==4);
 nb::collectPower(g.powers,b,'S'); assert(g.powers.shieldTimer==720);
 g.tick(200); assert(g.powers.wideTimer==719 && g.powers.shieldTimer==719);
 return 0;
}
