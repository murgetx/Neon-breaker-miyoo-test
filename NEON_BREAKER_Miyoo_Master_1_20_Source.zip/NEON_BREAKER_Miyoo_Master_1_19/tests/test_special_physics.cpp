#include "physics.hpp"
#include "special_blocks.hpp"
#include <cassert>
#include <vector>
int main(){
 using namespace nb;
 std::vector<Brick> b;
 b.push_back({100,100,18,12,1,1,0,0,BrickType::Steel});
 b.push_back({120,100,18,12,1,1,0,1,BrickType::Gold});
 Ball ball; ball.x=129; ball.y=126; ball.vx=0; ball.vy=-4; ball.r=5; ball.active=true;
 Paddle paddle; paddle.x=300; paddle.y=650;
 auto r=stepPhysics(ball,paddle,b,335);
 assert(b[0].hp==1); // steel is not damaged
 // A direct hit confirms gold score and damage semantics independent of trajectory.
 auto gold=hitBlock(b,1); assert(gold.destroyed && gold.score==100 && b[1].hp==0);
 std::vector<Brick> chain;
 chain.push_back({100,100,18,12,1,1,0,0,BrickType::Explosive});
 chain.push_back({120,100,18,12,1,1,0,1,BrickType::Normal});
 auto blast=hitBlock(chain,0); assert(blast.chainDestroyed.size()==2);
 std::vector<Brick> regen; regen.push_back({1,1,18,12,1,2,0,0,BrickType::Regen});
 updateSpecialBlocks(regen,300.0f,0.0f); assert(regen[0].hp==2);
}
