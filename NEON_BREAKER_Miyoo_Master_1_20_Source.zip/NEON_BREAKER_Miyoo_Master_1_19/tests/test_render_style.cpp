#include "render_style.hpp"
#include <cassert>
int main() {
    using namespace nb;
    const Rgb normal=brickFaceColor(BrickType::Normal,2,2);
    const Rgb steel=brickFaceColor(BrickType::Steel,2,2);
    const Rgb gold=brickFaceColor(BrickType::Gold,2,2);
    const Rgb damaged=brickFaceColor(BrickType::Normal,1,2);
    assert(normal.g>normal.r);
    assert(steel.b>steel.r);
    assert(gold.r>gold.b);
    assert(damaged.r<normal.r && damaged.g<normal.g && damaged.b<normal.b);
    assert(brickEdgeColor(BrickType::Explosive).r==255);
    assert(brickEdgeColor(BrickType::Moving).b>brickEdgeColor(BrickType::Moving).r);
    const Rgb invalid=brickFaceColor(BrickType::Normal,0,0);
    assert(invalid.r>0 && invalid.g>0 && invalid.b>0);
    return 0;
}
