#include "game_session.hpp"
#include <cassert>
int main(){
 nb::GameSession g; g.beginLevel(1);
 assert(g.levelTarget==262 && !g.levelComplete);
 // Empty the field: a non-boss level must register its clear and award the source target bonus.
 for(auto& b:g.layout.bricks)b.hp=0;
 g.levelScore=g.levelTarget;
 g.ball.active=false;
 g.tick(200);
 assert(g.levelComplete && g.levelBonus==600 && g.score==600);
 // A boss level cannot be marked clear while the boss is still alive.
 g.beginLevel(5);
 for(auto& b:g.layout.bricks)b.hp=0;
 g.ball.active=false;
 g.tick(200);
 assert(g.boss.active && !g.levelComplete);
 return 0;
}
