#include "settings.hpp"
#include <cassert>
#include <cstdio>
#include <fstream>
int main(){
 const char* p="test_audio_settings.cfg"; std::remove(p); std::remove("test_audio_settings.cfg.tmp"); std::remove("test_audio_settings.cfg.bak");
 nb::AudioSettings s; assert(!nb::loadAudioSettings(s,p));
 s.enabled=false; s.volume=0.35f; assert(nb::saveAudioSettings(s,p));
 nb::AudioSettings loaded; assert(nb::loadAudioSettings(loaded,p)); assert(!loaded.enabled); assert(loaded.volume>0.349f&&loaded.volume<0.351f);
 {std::ofstream bad(p,std::ios::trunc);bad<<"NEON_AUDIO 9 2 5.0\n";}
 nb::AudioSettings defaults; assert(!nb::loadAudioSettings(defaults,p));
 assert(!nb::saveAudioSettings(s,"")); s.volume=1.5f; assert(!nb::saveAudioSettings(s,p));
 std::remove(p); std::remove("test_audio_settings.cfg.bak"); return 0;
}
