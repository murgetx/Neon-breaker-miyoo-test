#include "campaign.hpp"
#include <cassert>
int main(){
 assert(nb::campaignStory.size()==100); assert(nb::campaignBossNames.size()==20); assert(nb::campaignDecisions.size()==6);
 assert(nb::campaignStory[0].number==1); assert(nb::campaignStory[99].number==100);
 nb::CampaignState c; assert(c.applyDecision(29,true)); assert(!c.applyDecision(29,false)); assert(c.values[0]==2&&c.values[1]==0);
 assert(c.applyDecision(45,false)); assert(c.values[2]==-2&&c.values[6]==-1&&c.values[3]==1);
 return 0;
}
