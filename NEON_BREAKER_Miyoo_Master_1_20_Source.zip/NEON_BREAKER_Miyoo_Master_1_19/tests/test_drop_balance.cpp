#include "powerups.hpp"
#include <cassert>
int main(){ uint32_t s=1234567; int n=0; for(int i=0;i<100000;++i)n+=nb::rollPowerDrop(s); double rate=n/100000.0; assert(rate>0.275 && rate<0.285); for(int i=0;i<1000;++i){char t=nb::choosePowerType(s); bool ok=false;for(char q:nb::powerTypes())if(q==t)ok=true;assert(ok);} }
