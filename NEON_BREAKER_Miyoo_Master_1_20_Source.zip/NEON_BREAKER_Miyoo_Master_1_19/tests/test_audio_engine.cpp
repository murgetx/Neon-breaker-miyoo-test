#include "audio_engine.hpp"
#include <cassert>
#include <cstdint>
#include <vector>
int main(){
 nb::AudioEngine a; std::vector<std::int16_t> b(4096*2);
 a.render(b.data(),4096,22050); bool audible=false; for(auto v:b) if(v!=0){audible=true;break;} assert(audible);
 a.setEnabled(false); a.render(b.data(),4096,22050); for(auto v:b) assert(v==0);
 a.setEnabled(true); a.setVolume(2.0f); assert(a.volume()==1.0f); a.setVolume(-1.0f); assert(a.volume()==0.0f);
}
