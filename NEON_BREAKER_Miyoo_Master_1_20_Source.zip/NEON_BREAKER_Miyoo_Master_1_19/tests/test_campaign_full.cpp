#include "campaign.hpp"
#include <cassert>
#include <set>
int main(){
 using namespace nb;
 assert(campaignStory.size()==100);
 CampaignState c;
 assert(c.applyDecision(29,true)); assert(!c.applyDecision(29,false));
 assert(c.values[0]==2 && c.decisionSeen(29));
 assert(c.branchText(30).find("PAŠERÁCKÁ")!=std::string::npos);
 assert(c.applyDecision(45,false)); assert(c.values[2]==-2 && c.values[6]==-1 && c.values[3]==1);
 assert(c.applyDecision(59,true)); assert(c.values[4]==2 && c.values[1]==1);
 assert(c.applyDecision(76,true)); assert(c.values[1]==3 && c.values[3]==2);
 assert(c.applyDecision(83,true)); assert(c.values[5]==2 && c.values[4]==3);
 assert(c.applyDecision(92,false)); assert(c.values[2]==-2 && c.values[6]==-2);
 assert(!c.applyDecision(92,true));
 assert(!c.endingTitle().empty() && !c.endingText().empty());
 std::set<std::string> titles;
 for(int mask=0;mask<64;mask++){CampaignState x;int lv[]={29,45,59,76,83,92};for(int i=0;i<6;i++)x.applyDecision(lv[i],(mask&(1<<i))==0);titles.insert(x.endingTitle());}
 assert(titles.size()==6);
 return 0;
}
