#include "game_session.hpp"
#include <cassert>
int main(){
 nb::GameSession g; g.beginLevel(5);
 assert(g.boss.active); assert(g.boss.hp>0);
 const int hp=g.boss.hp; nb::hitBoss(g.boss,5,1); assert(g.boss.hp==hp-1);
 g.beginLevel(6); assert(!g.boss.active);
 g.powers.paddleWidth=112; g.powers.wideTimer=1; g.tick(200); assert(g.powers.paddleWidth==70);
 return 0;
}
