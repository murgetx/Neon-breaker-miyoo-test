#include "input.hpp"
#include <cassert>
#include <cmath>
int main() {
    using nb::paddleTargetFromAxis;
    assert(std::abs(paddleTargetFromAxis(0) - 200.0) < 0.01);
    assert(std::abs(paddleTargetFromAxis(5999) - 200.0) < 0.01);
    assert(std::abs(paddleTargetFromAxis(-6000) - 200.0) < 0.01);
    assert(paddleTargetFromAxis(32767) > 374.9);
    assert(paddleTargetFromAxis(-32768) < 25.1);
    assert(paddleTargetFromAxis(12000) > 200.0);
    assert(paddleTargetFromAxis(-12000) < 200.0);
    assert(std::abs(paddleTargetFromAxis(32767, 0) - 375.0) < 0.01);
    return 0;
}
