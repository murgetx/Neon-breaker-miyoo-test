#include "hud.hpp"
#include <cassert>
#include <iostream>
int main(){
 nb::GameSession g; g.beginLevel(1);
 assert(nb::levelProgressPercent(g)==0);
 g.levelScore=g.levelTarget/2;
 assert(nb::levelProgressPercent(g)==50);
 g.levelScore=g.levelTarget*2;
 assert(nb::levelProgressPercent(g)==100);
 assert(nb::hudNumber(7,3)=="007");
 assert(nb::activePowerLabel(g)=="BONUS: NONE");
 g.powers.shieldTimer=61; g.powers.laserTimer=1;
 const auto label=nb::activePowerLabel(g);
 assert(label.find("SHIELD:2s")!=std::string::npos);
 assert(label.find("LASER:1s")!=std::string::npos);
 g.powers.extraBalls.resize(2);
 assert(nb::activePowerLabel(g).find("MULTI:2")!=std::string::npos);
 std::cout<<"HUD tests PASS\\n";
}
