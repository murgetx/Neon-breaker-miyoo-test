#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
CXX_BIN="${CXX:-g++}"
FLAGS="${CXXFLAGS:--std=c++17 -O0 -Wall -Wextra -pedantic}"
BUILD_DIR="${BUILD_DIR:-build/host-tests}"
mkdir -p "$BUILD_DIR"
COMMON=(src/levelgen.cpp src/physics.cpp src/powerups.cpp src/special_blocks.cpp src/bosses.cpp src/campaign.cpp src/savegame.cpp src/audio_engine.cpp src/settings.cpp)
OBJECTS=()
for source in "${COMMON[@]}"; do
  object="$BUILD_DIR/$(basename "${source%.cpp}").o"
  "$CXX_BIN" $FLAGS -Isrc -c "$source" -o "$object"
  OBJECTS+=("$object")
done
TESTS=(campaign session savegame boss_session integrated_powerups drop_balance weapon_and_drops special_physics level_clear campaign_full audio_engine settings input hud render_style effects)
for name in "${TESTS[@]}"; do
  echo "[BUILD] test_${name}"
  case "$name" in
    audio_engine) "$CXX_BIN" $FLAGS -Isrc "tests/test_${name}.cpp" "$BUILD_DIR/audio_engine.o" -o "$BUILD_DIR/test_${name}" ;;
    settings) "$CXX_BIN" $FLAGS -Isrc "tests/test_${name}.cpp" "$BUILD_DIR/settings.o" -o "$BUILD_DIR/test_${name}" ;;
    input|render_style|effects) "$CXX_BIN" $FLAGS -Isrc "tests/test_${name}.cpp" -o "$BUILD_DIR/test_${name}" ;;
    *) "$CXX_BIN" $FLAGS -Isrc "tests/test_${name}.cpp" "${OBJECTS[@]}" -o "$BUILD_DIR/test_${name}" ;;
  esac
  echo "[RUN] test_${name}"
  "$BUILD_DIR/test_${name}"
done
echo "ALL 16 TESTS PASSED"
