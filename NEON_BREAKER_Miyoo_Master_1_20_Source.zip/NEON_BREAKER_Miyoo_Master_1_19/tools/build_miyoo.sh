#!/usr/bin/env bash
# Run inside the steward-fu Miyoo SDL2 build container after SDL2 has been built.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDL_ROOT="${SDL_ROOT:-/work/sdl2}"
TOOLCHAIN_BIN="${TOOLCHAIN_BIN:-/opt/prebuilt/arm-linux-gnueabihf/bin}"
MINI_BIN="${MINI_BIN:-/opt/mini/bin}"
export PATH="$TOOLCHAIN_BIN:/opt/prebuilt/bin:$MINI_BIN:$PATH"
CXX="${CXX:-arm-linux-gnueabihf-g++}"
READELF="${READELF:-arm-linux-gnueabihf-readelf}"
OUT="$ROOT/dist/NEON_BREAKER/Roms/PORTS/Games/NEON_BREAKER"
mkdir -p "$OUT"

SDL_INCLUDE="$SDL_ROOT/include"
SDL_LIB="$SDL_ROOT/build/.libs"
if [[ ! -f "$SDL_INCLUDE/SDL.h" || ! -e "$SDL_LIB/libSDL2-2.0.so.0" ]]; then
  echo "Miyoo SDL2 headers or library not found" >&2
  exit 10
fi

"$CXX" -std=c++17 -O2 -Wall -Wextra -Isrc -I"$SDL_INCLUDE" \
  src/main_sdl.cpp src/levelgen.cpp src/physics.cpp src/powerups.cpp \
  src/special_blocks.cpp src/bosses.cpp src/campaign.cpp src/savegame.cpp \
  src/audio_engine.cpp src/settings.cpp \
  -L"$SDL_LIB" -Wl,-rpath,'$ORIGIN' -lSDL2-2.0 -pthread -lm -ldl \
  -o "$OUT/NEON_BREAKER"

# Bundle the Miyoo SDL2 runtime and its documented graphics dependencies.
cp -L "$SDL_LIB/libSDL2-2.0.so.0" "$OUT/"
cp -L "$SDL_ROOT/swiftshader/build/libEGL.so" "$OUT/"
cp -L "$SDL_ROOT/swiftshader/build/libGLESv2.so" "$OUT/"
JSON_LIB="$(find /opt/mini /opt/prebuilt -name 'libjson-c.so.5*' -type f -o -name 'libjson-c.so.5*' -type l 2>/dev/null | head -n1 || true)"
if [[ -n "$JSON_LIB" ]]; then cp -L "$JSON_LIB" "$OUT/libjson-c.so.5"; else echo "libjson-c.so.5 not found in toolchain" >&2; exit 11; fi

"$READELF" -h "$OUT/NEON_BREAKER" | grep -E 'Class:.*ELF32|Machine:.*ARM' >/dev/null
cat > "$OUT/launch.sh" <<'LAUNCH'
#!/bin/sh
cd "$(dirname "$0")"
export LD_LIBRARY_PATH="$(pwd):/config/lib:/customer/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
exec ./NEON_BREAKER "$@"
LAUNCH
chmod +x "$OUT/launch.sh" "$OUT/NEON_BREAKER"
cat > "$OUT/README_INSTALL_CZ.txt" <<'INSTALL'
NEON BREAKER – Miyoo Mini Plus / OnionOS

Toto je ARM sestaveni. Rozbalte obsah archivu na koren SD karty a sloucete slozku Roms.
Hru spustte pres dodany launch.sh. Pokud se hra neobjevi v Ports seznamu, je potreba doplnit OnionOS shortcut .port podle sablony konkretni verze Ports Collection.

Ulozene pozice a nastaveni se ukladaji do adresare hry.
INSTALL

mkdir -p "$ROOT/dist"
