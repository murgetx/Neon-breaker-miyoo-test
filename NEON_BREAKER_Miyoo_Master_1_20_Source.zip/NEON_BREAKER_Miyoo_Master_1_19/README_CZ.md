# NEON BREAKER – Miyoo Mini Plus native port (Master 1.19)

Zdrojový projekt nativního portu NEON BREAKER pro Miyoo Mini Plus / OnionOS.

## Obsah
- `src/` – C++ herní logika, SDL2 frontend, zvuk, nastavení a částicové efekty.
- `tests/` – samostatné testy herních systémů.
- `data/` – data kampaně a bossů.
- `source_original/` – nedotčený původní HTML 11.9.9 jako referenční zdroj.
- `docs/` – changelogy a stav sestavení.

## Testy na hostitelském systému
```sh
make test
```

## SDL2 sestavení
Vyžaduje SDL2 vývojové hlavičky a knihovny. Pro Miyoo je nutné použít odpovídající ARM toolchain a knihovny cílového systému.

**Upozornění:** Tento ZIP obsahuje zdrojové kódy. Není to hotový instalační balík OnionOS a neobsahuje ověřenou ARM binárku. Kompatibilita s konkrétní instalací OnionOS a běh na fyzickém Miyoo zatím nejsou potvrzené.

## Master 1.20 – ARM build pipeline

- `./tools/run_tests.sh` sestaví sdílené objekty a spustí všech 16 testů.
- `.github/workflows/build-miyoo.yml` připravuje GitHub Actions host testy a ARM cross-build pro Miyoo Mini Plus.
- `tools/build_miyoo.sh` se spouští uvnitř build kontejneru s Miyoo toolchainem a SDL2 knihovnou.

Workflow nebyl v tomto balíku spuštěn na GitHubu. Dokud nebude úspěšně dokončen, neexistuje potvrzená ARM binárka. Výsledný balík zatím nemá Onion Ports `.port` shortcut; fyzický test na zařízení je stále nutný.
