# Stav portu NEON BREAKER – Master 1.20

Master 1.20 navazuje na 1.19 a ponechává původní HTML 11.9.9, herní data, SDL2 frontend a herní systémy beze změny.

## Připraveno
- GitHub Actions workflow pro 16 hostitelských testů a Miyoo ARM cross-build.
- Skript pro efektivnější spuštění všech 16 testovacích programů.
- ARM build skript s kontrolou cílové architektury ELF32/ARM.
- Příprava runtime knihoven SDL2, EGL, GLESv2 a json-c.
- Základní OnionOS `Roms/PORTS/Games/NEON_BREAKER` struktura.

## Stav ověření v tomto balíku
- Původní `make test` byl spuštěn, ale při kompilaci `test_level_clear` překročil časový limit prostředí.
- Nový `tools/run_tests.sh` je připraven pro spuštění v CI; jeho úplný běh zatím není potvrzen.
- GitHub Actions workflow nebyl spuštěn.
- ARM binárka nebyla vytvořena ani ověřena.
- `.port` shortcut pro Ports Collection zatím není součástí balíku.
- Fyzický běh na Miyoo Mini Plus není ověřen.

## Další krok
Nahrát Master 1.20 do repozitáře `murgetx/neon-breaker-miyoo-test`, spustit workflow v GitHub Actions, opravit případné chyby kompilace a stáhnout ARM artefakt až po zeleném běhu.
