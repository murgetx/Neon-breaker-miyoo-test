#include "special_blocks.hpp"
#include <algorithm>
#include <cmath>
#include <queue>
namespace nb {
BlockHit hitBlock(std::vector<Brick>& b, std::size_t i) {
 BlockHit out; if(i>=b.size() || b[i].hp<=0) return out;
 Brick& first=b[i]; out.consumed=true;
 if(first.type==BrickType::Steel){out.steel=true;return out;}
 first.regenClock=0.0f; --first.hp;
 if(first.hp>0){out.score=5;return out;}
 std::queue<std::size_t> q; q.push(i);
 while(!q.empty()){
  auto n=q.front();q.pop(); if(b[n].hp>0) continue;
  b[n].hp=0; out.chainDestroyed.push_back(n); out.destroyed=true;
  out.score += b[n].type==BrickType::Gold ? 100 : 10;
  if(b[n].type!=BrickType::Explosive) continue;
  const float cx=b[n].x+b[n].w/2.0f, cy=b[n].y+b[n].h/2.0f;
  for(std::size_t j=0;j<b.size();++j){
   if(j==n || b[j].hp<=0 || b[j].type==BrickType::Steel) continue;
   float dx=std::fabs((b[j].x+b[j].w/2.0f)-cx),dy=std::fabs((b[j].y+b[j].h/2.0f)-cy);
   if(dx>=68 || dy>=45) continue;
   b[j].regenClock=0.0f; --b[j].hp;
   if(b[j].hp<=0) q.push(j);
  }
 }
 return out;
}
void updateSpecialBlocks(std::vector<Brick>& blocks,float dt,float tick){
 for(auto& b:blocks){ if(b.hp<=0) continue;
  if(b.type==BrickType::Moving) b.x=static_cast<int>(std::lround(b.baseX+3.5f*std::sin(tick+b.phase)));
  if(b.type==BrickType::Regen){ b.regenClock=std::min(300.0f,b.regenClock+dt); if(b.regenClock>=300.0f && b.hp<b.maxHp){++b.hp;b.regenClock=0.0f;} }
 }
}
}
