#pragma once
#include "levelgen.hpp"
#include <vector>
#include <cstddef>
namespace nb {
struct BlockHit { bool consumed=false, destroyed=false, steel=false; int score=0; std::vector<std::size_t> chainDestroyed; };
BlockHit hitBlock(std::vector<Brick>& blocks, std::size_t index);
void updateSpecialBlocks(std::vector<Brick>& blocks, float dt, float tick);
}
