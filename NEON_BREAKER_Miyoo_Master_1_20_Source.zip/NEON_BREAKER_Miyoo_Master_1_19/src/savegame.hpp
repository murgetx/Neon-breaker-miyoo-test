#pragma once
#include "game_session.hpp"
#include <string>
namespace nb {
bool saveGame(const GameSession& game, const std::string& path);
bool loadGame(GameSession& game, const std::string& path);
}
