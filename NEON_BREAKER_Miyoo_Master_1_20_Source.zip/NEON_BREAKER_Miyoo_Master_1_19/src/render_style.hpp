#pragma once
#include "levelgen.hpp"
#include <algorithm>
#include <cstdint>

namespace nb {
struct Rgb { std::uint8_t r, g, b; };
inline Rgb brickFaceColor(BrickType type, int hp, int maxHp) {
    const int strength = maxHp > 0 ? std::clamp((hp * 100) / maxHp, 0, 100) : 0;
    int r=80, g=170, b=105;
    switch (type) {
        case BrickType::Normal:    r=74;  g=178; b=112; break;
        case BrickType::Steel:     r=112; g=139; b=164; break;
        case BrickType::Gold:      r=218; g=166; b=55;  break;
        case BrickType::Explosive: r=205; g=76;  b=55;  break;
        case BrickType::Regen:     r=83;  g=155; b=202; break;
        case BrickType::Moving:    r=166; g=111; b=194; break;
    }
    const int factor = 55 + strength * 45 / 100;
    return {static_cast<std::uint8_t>(r*factor/100),
            static_cast<std::uint8_t>(g*factor/100),
            static_cast<std::uint8_t>(b*factor/100)};
}
inline Rgb brickEdgeColor(BrickType type) {
    switch (type) {
        case BrickType::Steel: return {205,220,232};
        case BrickType::Gold: return {255,224,128};
        case BrickType::Explosive: return {255,145,112};
        case BrickType::Regen: return {154,220,255};
        case BrickType::Moving: return {220,170,245};
        default: return {170,230,180};
    }
}
}
