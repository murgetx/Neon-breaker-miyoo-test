#pragma once
#include <string>
namespace nb {
struct AudioSettings { bool enabled = true; float volume = 0.55f; };
// Loads validated audio preferences. Missing or malformed files keep safe defaults.
bool loadAudioSettings(AudioSettings& settings, const std::string& path) noexcept;
// Writes settings atomically through a temporary file; returns false on any I/O error.
bool saveAudioSettings(const AudioSettings& settings, const std::string& path) noexcept;
}
