#include "physics.hpp"
#include "special_blocks.hpp"
#include <algorithm>
#include <cmath>
namespace nb {
PhysicsResult stepPhysics(Ball& q, Paddle& p, std::vector<Brick>& bricks, double target) {
 PhysicsResult out; p.x=std::clamp(target-p.w/2.0,0.0,400.0-p.w);
 if(!q.active) return out;
 const int steps=std::max(1,(int)std::ceil(std::hypot(q.vx,q.vy)/std::max(2.0,q.r*.5)));
 for(int s=0;s<steps;s++) {
  double px=q.x, py=q.y; q.x+=q.vx/steps; q.y+=q.vy/steps;
  if(q.x<q.r){q.x=q.r;q.vx=std::abs(q.vx);} if(q.x>400-q.r){q.x=400-q.r;q.vx=-std::abs(q.vx);} if(q.y<q.r){q.y=q.r;q.vy=std::abs(q.vy);}
  bool crossed=q.vy>0 && py+q.r<=p.y && q.y+q.r>=p.y;
  double t=crossed?std::clamp((p.y-(py+q.r))/(q.y-py),0.0,1.0):1.0;
  double hx=px+(q.x-px)*t;
  if(q.vy>0 && (crossed?(hx>=p.x-q.r&&hx<=p.x+p.w+q.r):(q.y+q.r>=p.y&&q.y-q.r<=p.y+p.h&&q.x>=p.x-2&&q.x<=p.x+p.w+2))) {
   if(crossed){q.x=hx;q.y=p.y-q.r;}
   double hit=std::clamp((q.x-(p.x+p.w/2))/(p.w/2),-1.0,1.0);
   double speed=std::clamp(std::hypot(q.vx,q.vy),4.15,6.8), angle=hit*.88;
   q.vx=std::sin(angle)*speed; q.vy=-std::cos(angle)*speed;
  }
  for(std::size_t bi=0; bi<bricks.size(); ++bi) {
   auto &b=bricks[bi];
   if(b.hp<=0 || q.x+q.r<=b.x || q.x-q.r>=b.x+b.w || q.y+q.r<=b.y || q.y-q.r>=b.y+b.h) continue;
   double ol=q.x+q.r-b.x,orr=b.x+b.w-(q.x-q.r),ot=q.y+q.r-b.y,ob=b.y+b.h-(q.y-q.r);
   bool left=px+q.r<=b.x,right=px-q.r>=b.x+b.w,above=py+q.r<=b.y,below=py-q.r>=b.y+b.h;
   if(left&&(!above&&!below||std::min(ol,orr)<std::min(ot,ob))){q.x=b.x-q.r;q.vx=-std::abs(q.vx);} 
   else if(right&&(!above&&!below||std::min(ol,orr)<std::min(ot,ob))){q.x=b.x+b.w+q.r;q.vx=std::abs(q.vx);}
   else if(above||(!below&&std::min(ot,ob)<=std::min(ol,orr))){q.y=b.y-q.r;q.vy=-std::abs(q.vy);}
   else {q.y=b.y+b.h+q.r;q.vy=std::abs(q.vy);}
   auto hit=hitBlock(bricks,bi);
   if(hit.consumed && !hit.steel){
    ++out.bricksDamaged; out.bricksDestroyed+=(int)hit.chainDestroyed.size(); out.scoreAward+=hit.score;
    for(auto idx:hit.chainDestroyed) out.destroyedAt.push_back({bricks[idx].x+bricks[idx].w/2.0,bricks[idx].y+bricks[idx].h/2.0});
   }
   break;
  }
  if(q.y>708){q.active=false;out.lostBall=true;return out;}
 }
 return out;
}
}
