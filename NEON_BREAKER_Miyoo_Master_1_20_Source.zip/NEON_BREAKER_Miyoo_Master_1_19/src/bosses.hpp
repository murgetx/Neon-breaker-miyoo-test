#pragma once
#include <vector>
#include <string>
namespace nb {
struct Shot { double x=0,y=0,vx=0,vy=0,r=5; };
struct BossState { double x=135,y=145,w=130,h=30,vx=2.1; int hp=0,phase=1,cooldown=45,flash=0; bool active=false; std::vector<Shot> shots; };
struct BossInput { int level=5,frame=0; double paddleX=165,paddleW=70,paddleY=650; };
extern const char* const bossNames[20];
void initBoss(BossState& boss, int level);
void updateBoss(BossState& boss, const BossInput& input);
void hitBoss(BossState& boss, int level, int damage=1);
}
