#include "savegame.hpp"
#include <fstream>
#include <cmath>
#include <string>
#include <cstdio>
#include <utility>
namespace nb {
bool saveGame(const GameSession& g, const std::string& path) {
 // Reject invalid runtime values before touching the last known-good save.
 if(g.level<1 || g.level>100 || g.lives<0 || g.lives>99 ||
    !std::isfinite(g.ball.x) || !std::isfinite(g.ball.y) ||
    !std::isfinite(g.ball.vx) || !std::isfinite(g.ball.vy) ||
    !std::isfinite(g.paddle.x) || !std::isfinite(g.paddle.y) ||
    !std::isfinite(g.paddle.w) || !std::isfinite(g.paddle.h)) return false;
 const std::string temp=path+".tmp";
 const std::string backup=path+".bak";
 std::ofstream f(temp, std::ios::trunc); if(!f) return false;
 f.precision(17);
 f << "NEON_BREAKER_SAVE 6\n" << g.level << ' ' << g.score << ' ' << g.levelScore << ' ' << g.lives << ' ' << g.frame << ' ' << g.rngState << ' ' << g.levelTarget << ' ' << g.levelBonus << ' ' << g.levelComplete << '\n';
 f << g.ball.x << ' ' << g.ball.y << ' ' << g.ball.vx << ' ' << g.ball.vy << ' ' << g.ball.r << ' ' << g.ball.active << '\n';
 f << g.paddle.x << ' ' << g.paddle.y << ' ' << g.paddle.w << ' ' << g.paddle.h << '\n';
 f << g.campaignMode << ' ' << g.powers.paddleWidth << ' ' << g.powers.lives << ' ' << g.powers.score << ' '
   << g.powers.wideTimer << ' ' << g.powers.laserTimer << ' ' << g.powers.slowTimer << ' '
   << g.powers.shieldTimer << ' ' << g.powers.catchTimer << ' ' << g.powers.fireTimer << ' ' << g.powers.gunTimer << '\n';
 f << g.layout.bricks.size(); for(const auto& b:g.layout.bricks) f << ' ' << b.hp; f << '\n';
 f << g.boss.active << ' ' << g.boss.x << ' ' << g.boss.y << ' ' << g.boss.w << ' ' << g.boss.h << ' ' << g.boss.vx << ' ' << g.boss.hp << ' ' << g.boss.phase << ' ' << g.boss.cooldown << ' ' << g.boss.flash << '\n';
 f << g.boss.shots.size(); for(const auto& q:g.boss.shots) f << ' ' << q.x << ' ' << q.y << ' ' << q.vx << ' ' << q.vy << ' ' << q.r; f << '\n';
 f << g.falling.size(); for(const auto& q:g.falling) f << ' ' << q.x << ' ' << q.y << ' ' << q.vy << ' ' << q.type; f << '\n';
 f << g.powers.extraBalls.size(); for(const auto& q:g.powers.extraBalls) f << ' ' << q.x << ' ' << q.y << ' ' << q.vx << ' ' << q.vy << ' ' << q.fire; f << '\n';
 f << g.powers.shots.size(); for(const auto& q:g.powers.shots) f << ' ' << q.x << ' ' << q.y << ' ' << q.damage << ' ' << q.speed; f << '\n';
 for(int v:g.campaign.values) f << v << ' '; for(bool v:g.campaign.seen) f << v << ' '; f << '\n';
 f.flush();
 const bool written=static_cast<bool>(f);
 f.close();
 if(!written){ std::remove(temp.c_str()); return false; }
 // Keep one previous generation so an interrupted replacement can be rolled back.
 std::remove(backup.c_str());
 const bool hadOriginal=(std::rename(path.c_str(),backup.c_str())==0);
 if(!hadOriginal){
  // A missing original is normal for the first save; other rename failures are
  // detected by checking whether the destination still exists.
  std::ifstream existing(path); if(existing.good()){ std::remove(temp.c_str()); return false; }
 }
 if(std::rename(temp.c_str(),path.c_str())!=0){
  if(hadOriginal) std::rename(backup.c_str(),path.c_str());
  std::remove(temp.c_str()); return false;
 }
 return true;
}
bool loadGame(GameSession& g, const std::string& path) {
 std::ifstream f(path); if(!f) return false;
 std::string magic; int version=0; if(!(f>>magic>>version) || magic!="NEON_BREAKER_SAVE" || version!=6) return false;
 GameSession t;
 if(!(f>>t.level>>t.score>>t.levelScore>>t.lives>>t.frame>>t.rngState>>t.levelTarget>>t.levelBonus>>t.levelComplete) || t.level<1 || t.level>100 || t.lives<0 || t.lives>99) return false;
 if(!(f>>t.ball.x>>t.ball.y>>t.ball.vx>>t.ball.vy>>t.ball.r>>t.ball.active)) return false;
 if(!(f>>t.paddle.x>>t.paddle.y>>t.paddle.w>>t.paddle.h)) return false;
 if(!(f>>t.campaignMode>>t.powers.paddleWidth>>t.powers.lives>>t.powers.score>>t.powers.wideTimer>>t.powers.laserTimer>>t.powers.slowTimer>>t.powers.shieldTimer>>t.powers.catchTimer>>t.powers.fireTimer>>t.powers.gunTimer)) return false;
 const int savedLevelScore=t.levelScore;
 t.beginLevel(t.level); t.levelScore=savedLevelScore;
 std::size_t count=0; if(!(f>>count) || count!=t.layout.bricks.size()) return false;
 for(auto& b:t.layout.bricks) if(!(f>>b.hp) || b.hp<0 || b.hp>b.maxHp) return false;
 if(!(f>>t.boss.active>>t.boss.x>>t.boss.y>>t.boss.w>>t.boss.h>>t.boss.vx>>t.boss.hp>>t.boss.phase>>t.boss.cooldown>>t.boss.flash)) return false;
 if(t.boss.hp<0 || t.boss.hp>200 || t.boss.phase<1 || t.boss.phase>2) return false;
 if(!(f>>count) || count>100) return false; t.boss.shots.clear();
 for(std::size_t i=0;i<count;++i){ Shot q; if(!(f>>q.x>>q.y>>q.vx>>q.vy>>q.r)) return false; if(!std::isfinite(q.x)||!std::isfinite(q.y)||q.r<0||q.r>30)return false; t.boss.shots.push_back(q); }
 if(!(f>>count) || count>30)return false; t.falling.clear();
 for(std::size_t i=0;i<count;++i){FallingPower q;if(!(f>>q.x>>q.y>>q.vy>>q.type))return false;if(!std::isfinite(q.x)||!std::isfinite(q.y)||std::string("WRZFCGLBT PMS").find(q.type)==std::string::npos)return false;t.falling.push_back(q);}
 if(!(f>>count)||count>4)return false;t.powers.extraBalls.clear();
 for(std::size_t i=0;i<count;++i){PowerBall q;if(!(f>>q.x>>q.y>>q.vx>>q.vy>>q.fire))return false;t.powers.extraBalls.push_back(q);}
 if(!(f>>count)||count>80)return false;t.powers.shots.clear();
 for(std::size_t i=0;i<count;++i){PowerShot q;if(!(f>>q.x>>q.y>>q.damage>>q.speed)||q.damage<1||q.damage>5||q.speed<1||q.speed>20)return false;t.powers.shots.push_back(q);}
 for(int& v:t.campaign.values) if(!(f>>v)) return false;
 for(std::size_t i=0;i<t.campaign.seen.size();++i){ bool v=false; if(!(f>>v)) return false; t.campaign.seen[i]=v; }
 if(!std::isfinite(t.ball.x)||!std::isfinite(t.ball.y)||!std::isfinite(t.ball.vx)||!std::isfinite(t.ball.vy)||t.ball.x<0||t.ball.x>400||t.ball.y<0||t.ball.y>720||t.paddle.w<20||t.paddle.w>200) return false;
 t.powers.lives=t.lives; t.powers.score=t.score; g=t; return true;
}
}
