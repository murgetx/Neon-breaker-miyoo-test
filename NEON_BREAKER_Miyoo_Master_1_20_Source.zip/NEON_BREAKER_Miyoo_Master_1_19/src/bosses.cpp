#include "bosses.hpp"
#include <algorithm>
#include <cmath>
namespace nb {
const char* const bossNames[20]={
"Revizor Pepa","Kapitán Rumová Koule","DJ Beton","Král pašeráků","Doktor Suchar","Automatický policajt","Baron Koksík","Inspektor Bez Úsměvu","Generál Dezinfekce","Rave Terminátor","Laboratorní mutant","Černý DJ","Ředitel ČISTÉHO DECHU","Stín ŠROT-7","Zmutovaný botanický experiment","Strážce biologického trezoru","Nejvyšší ředitel ČISTÉHO DECHU","DJ Tichoun – první střet","Generál Ticho – fáze I","Generál Ticho – finální drop"};
static void add(BossState& b,double x,double y,double vx,double vy,double r){b.shots.push_back({x,y,vx,vy,r});}
void initBoss(BossState& b,int level){b=BossState{};b.hp=12+(level/5)*2/2; /* replaced below by exact source formula */ b.hp=12+(int)std::floor(level*.5);b.vx=std::min(4.6,2.1+level*.025);b.active=(level%5==0);b.cooldown=45;}
void hitBoss(BossState& b,int level,int damage){b.hp=std::max(0,b.hp-damage);b.phase=b.hp<=(12+(int)std::floor(level*.5))*.5?2:1;b.flash=7;if(!b.hp){b.shots.clear();b.active=false;}}
void updateBoss(BossState& b,const BossInput& in){
 if(in.level%5||b.hp<=0)return;
 const int no=in.level/5,motion=(no-1)%5;const double pf=b.phase==2?1.22:1.0;
 if(motion==0)b.vx+=std::sin(in.frame*.035+no)*.075*pf;
 else if(motion==1)b.vx+=std::sin(in.frame*.09+no)*.12*pf;
 else if(motion==2)b.vx+=std::sin(in.frame*.018+no)*.045*pf;
 else if(motion==3){b.vx+=std::sin(in.frame*.055+no)*.095*pf;if(in.frame%150<75)b.vx+=.018*pf;else b.vx-=.018*pf;}
 else b.vx+=std::sin(in.frame*.12+no)*.14*pf;
 const double vmax=(motion==1||motion==4?3.2:motion==2?1.65:2.5)*pf;b.vx=std::max(-vmax,std::min(vmax,b.vx));b.x+=b.vx;
 if(b.x<12){b.x=12;b.vx=std::abs(b.vx);}if(b.x+b.w>388){b.x=388-b.w;b.vx=-std::abs(b.vx);}if(b.flash>0)--b.flash;
 if(--b.cooldown<=0){double dx=in.paddleX+in.paddleW/2-(b.x+b.w/2),dy=in.paddleY-b.y,mag=std::max(1.0,std::hypot(dx,dy)),speed=std::min(5.8,2.4+in.level*.035),cx=b.x+b.w/2,by=b.y+b.h;int side=((in.frame/90)%2==0)?-1:1;
 switch(no){
 case 1:add(b,cx,by,dx/mag*speed,dy/mag*speed,7);break;
 case 2:for(int i=-1;i<=1;i++)add(b,cx+i*24,by,i*1.45,speed,5);break;
 case 3:for(int i=-2;i<=2;i++)add(b,cx+i*12,by,i*.72,speed*.92,5);break;
 case 4:add(b,cx-38,by,-2,speed,6);add(b,cx+38,by,2,speed,6);break;
 case 5:for(int i=-1;i<=1;i++)add(b,cx+i*18,by,dx/mag*speed+i*.8,dy/mag*speed,5);break;
 case 6:add(b,cx,by,-1.65,speed,6);add(b,cx,by,1.65,speed,6);break;
 case 7:for(int i=0;i<4;i++){double a=-.72+i*.48;add(b,cx,by,std::sin(a)*speed,std::cos(a)*speed,5);}break;
 case 8:add(b,cx+side*34,by,side*2.4,speed,6);add(b,cx-side*34,by,-side*.55,speed*.85,5);break;
 case 9:for(int i=-1;i<=1;i++)add(b,cx+i*30,by,-i*1.25,speed,6);break;
 case 10:add(b,cx,by,dx/mag*speed*.7,dy/mag*speed*.7,9);break;
 case 11:for(int i=-2;i<=2;i++)add(b,cx+i*16,by,i*.48,speed+(2-std::abs(i))*.12,4);break;
 case 12:add(b,cx-46,by,1.25,speed*.9,6);add(b,cx+46,by,-1.25,speed*.9,6);break;
 case 13:for(int i=-1;i<=1;i++)add(b,cx+i*22,by,dx/mag*speed+i*.55,dy/mag*speed,6);break;
 case 14:add(b,cx,by,-2.35,speed*.82,5);add(b,cx,by,0,speed*1.08,7);add(b,cx,by,2.35,speed*.82,5);break;
 case 15:for(int i=0;i<5;i++){double a=-.9+i*.45;add(b,cx,by,std::sin(a)*speed*.85,std::cos(a)*speed*.85,5);}break;
 case 16:add(b,cx-30,by,-1.8,speed,5);add(b,cx+30,by,1.8,speed,5);add(b,cx,by,dx/mag*speed*.65,dy/mag*speed*.65,6);break;
 case 17:for(int i=-1;i<=1;i++)add(b,cx+i*26,by,i*.95,speed+(i==0?.45:0),6);break;
 case 18:add(b,cx,by,dx/mag*speed,dy/mag*speed,5);add(b,cx-42,by,-2.1,speed*.8,5);add(b,cx+42,by,2.1,speed*.8,5);break;
 case 19:for(int i=-2;i<=2;i++)add(b,cx+i*20,by,-i*.7,speed*.88,5);break;
 case 20:add(b,cx-24,by,-1.8,speed+.5,6);add(b,cx,by,dx/mag*speed,dy/mag*speed,7);add(b,cx+24,by,1.8,speed+.5,6);break;
 }
 if(b.phase==2){add(b,cx-24,by,-1.8,speed+.6,5);add(b,cx+24,by,1.8,speed+.6,5);}
 for(auto& s:b.shots){double v=std::hypot(s.vx,s.vy);if(v>6.4){s.vx=s.vx/v*6.4;s.vy=s.vy/v*6.4;}}
 b.cooldown=std::max(42,110-(int)std::floor(in.level*2.5));
 }
 for(auto& s:b.shots){s.x+=s.vx;s.y+=s.vy;}b.shots.erase(std::remove_if(b.shots.begin(),b.shots.end(),[](const Shot&s){return s.y>=720||s.x<=-10||s.x>=410;}),b.shots.end());
}
}
