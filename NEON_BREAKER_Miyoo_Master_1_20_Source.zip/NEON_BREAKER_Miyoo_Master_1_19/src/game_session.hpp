#pragma once
#include "levelgen.hpp"
#include "physics.hpp"
#include "powerups.hpp"
#include "special_blocks.hpp"
#include "bosses.hpp"
#include "campaign.hpp"
#include <algorithm>
#include <cmath>
#include <vector>
#include <cstdint>
namespace nb {
struct GameSession {
 int level=1, score=0, levelScore=0, lives=3, frame=0; uint32_t rngState=0x4E425231u;
 LevelLayout layout; Ball ball; Paddle paddle; PowerState powers; BossState boss; CampaignState campaign;
 std::vector<FallingPower> falling;
 bool campaignMode=true, levelComplete=false, gameOver=false;
 int levelTarget=262, levelBonus=0;
 void beginLevel(int n){
  level=std::clamp(n,1,100); layout=buildLevel(level); ball=Ball{}; paddle=Paddle{};
  powers=PowerState{}; powers.lives=lives; powers.score=score; falling.clear();
  levelScore=0; levelTarget=250+level*12; levelBonus=0; levelComplete=false; initBoss(boss,level);
 }
 PhysicsResult tick(double paddleTarget){
  ++frame; tickPowerTimers(powers); paddle.w=powers.paddleWidth;
  updateSpecialBlocks(layout.bricks,1.0f/60.0f,static_cast<float>(frame)/60.0f);
  // Fire modes from the original game: laser every 18 frames, gun every 28.
  if(powers.laserTimer>0 && frame%18==0){ powers.shots.push_back({paddle.x+12,paddle.y,2,8.0}); powers.shots.push_back({paddle.x+paddle.w-12,paddle.y,2,8.0}); }
  else if(powers.gunTimer>0 && frame%28==0){ powers.shots.push_back({paddle.x+12,paddle.y,1,7.0}); powers.shots.push_back({paddle.x+paddle.w-12,paddle.y,1,7.0}); }
  if(powers.slowTimer>0){ const double speed=std::hypot(ball.vx,ball.vy); if(speed>0){const double ns=std::min(speed,4.2);ball.vx*=ns/speed;ball.vy*=ns/speed;} }
  const double oldY=ball.y;
  auto r=stepPhysics(ball,paddle,layout.bricks,paddleTarget);
  levelScore+=r.scoreAward; score+=r.scoreAward;
  // Balanced source-faithful drop: 28% per destroyed brick, uniform 12-type pool.
  for(const auto& pos:r.destroyedAt){ if(rollPowerDrop(rngState)) falling.push_back({pos.first,pos.second,1.8,choosePowerType(rngState),false}); }
  // Weapon shots travel upward and damage blocks or boss.
  for(auto& shot:powers.shots){ shot.y-=shot.speed; bool spent=false;
   if(boss.active && shot.x>=boss.x && shot.x<=boss.x+boss.w && shot.y>=boss.y && shot.y<=boss.y+boss.h){ hitBoss(boss,level,shot.damage); score+=80+level*5; spent=true; }
   if(!spent) for(auto& brick:layout.bricks){ if(brick.hp>0 && shot.x>=brick.x && shot.x<=brick.x+brick.w && shot.y>=brick.y && shot.y<=brick.y+brick.h){ brick.hp=std::max(0,brick.hp-shot.damage); if(brick.hp==0){score+=15;levelScore+=15;} spent=true; break; } }
   if(spent)shot.y=-100;
  }
  powers.shots.erase(std::remove_if(powers.shots.begin(),powers.shots.end(),[](const PowerShot& q){return q.y<-20;}),powers.shots.end());
  for(auto& p:falling){ if(p.collected)continue; p.y+=p.vy; if(p.y+7>=paddle.y && p.y-7<=paddle.y+paddle.h && p.x>=paddle.x-5 && p.x<=paddle.x+paddle.w+5){ PowerBall pb{ball.x,ball.y,ball.vx,ball.vy,p.type=='P'}; collectPower(powers,pb,p.type); score=powers.score; lives=powers.lives; p.collected=true; } else if(p.y>715)p.collected=true; }
  falling.erase(std::remove_if(falling.begin(),falling.end(),[](const FallingPower& p){return p.collected;}),falling.end());
  // Additional balls share the same paddle and brick field.
  for(auto& extra:powers.extraBalls){ if(extra.y>708)continue; Ball eb{extra.x,extra.y,extra.vx,extra.vy,7,true}; auto er=stepPhysics(eb,paddle,layout.bricks,paddleTarget); extra.x=eb.x;extra.y=eb.y;extra.vx=eb.vx;extra.vy=eb.vy; if(er.bricksDestroyed){score+=er.bricksDestroyed*10;levelScore+=er.bricksDestroyed*10;} }
  powers.extraBalls.erase(std::remove_if(powers.extraBalls.begin(),powers.extraBalls.end(),[](const PowerBall& b){return b.y>708;}),powers.extraBalls.end());
  if(boss.active && ball.active){
   const bool overlap=ball.x+ball.r>boss.x && ball.x-ball.r<boss.x+boss.w && ball.y+ball.r>boss.y && ball.y-ball.r<boss.y+boss.h;
   if(overlap && (oldY+ball.r<=boss.y+boss.h || oldY-ball.r>=boss.y)){ ball.vy=oldY<boss.y+boss.h/2?-std::abs(ball.vy):std::abs(ball.vy);hitBoss(boss,level,1);score+=25;levelScore+=25; }
  }
  if(boss.active){ updateBoss(boss,{level,frame,paddle.x,paddle.w,paddle.y}); for(auto& shot:boss.shots){const bool hit=shot.x+shot.r>=paddle.x&&shot.x-shot.r<=paddle.x+paddle.w&&shot.y+shot.r>=paddle.y&&shot.y-shot.r<=paddle.y+paddle.h;if(hit){shot.y=730;if(powers.shieldTimer<=0&&--lives<=0)gameOver=true;}} if(!boss.hp)boss.active=false; }
  powers.lives=lives; powers.score=score;
  // The original campaign awards a clear bonus only after the score target is met.
  // A boss level cannot finish until both its brick field and boss are cleared.
  const bool bricksRemain=std::any_of(layout.bricks.begin(),layout.bricks.end(),[](const Brick& b){return b.hp>0;});
  if(!bricksRemain && !boss.active && !levelComplete){
   levelComplete=true;
   if(levelScore>=levelTarget){ levelBonus=500+level*100; score+=levelBonus; }
  }
  if(r.lostBall){if(powers.shieldTimer>0)ball=Ball{};else if(--lives<=0)gameOver=true;else ball=Ball{};}
  return r;
 }
 bool cleared() const { return levelComplete && !gameOver; }
 const StoryChapter& story() const { return campaignStory[static_cast<std::size_t>(std::clamp(level,1,100)-1)]; }
 bool chooseStory(int chapter,bool optionA){ return campaign.applyDecision(chapter,optionA); }
};
}
