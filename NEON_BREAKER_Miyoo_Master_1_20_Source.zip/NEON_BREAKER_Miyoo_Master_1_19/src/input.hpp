#pragma once
#include <algorithm>
#include <cmath>

namespace nb {
// Convert SDL's signed left-stick axis into the game's 0..400 paddle space.
// A 6,000-unit dead zone prevents stick drift on handheld controls.
inline double paddleTargetFromAxis(int axisValue, int deadZone = 6000) noexcept {
    const int clamped = std::clamp(axisValue, -32768, 32767);
    const int dz = std::clamp(deadZone, 0, 16000);
    if (std::abs(clamped) <= dz) return 200.0;
    const double magnitude = (static_cast<double>(std::abs(clamped)) - dz) / (32768.0 - dz);
    const double signedPosition = std::copysign(std::clamp(magnitude, 0.0, 1.0), static_cast<double>(clamped));
    return std::clamp(200.0 + signedPosition * 175.0, 25.0, 375.0);
}
}
