#pragma once
#include "game_session.hpp"
#include <algorithm>
#include <string>
#include <cstdio>

namespace nb {
inline std::string hudNumber(int value, int width) {
    char out[32];
    std::snprintf(out, sizeof(out), "%0*d", width, std::max(0, value));
    return out;
}
inline int levelProgressPercent(const GameSession& g) {
    if (g.levelTarget <= 0) return 100;
    return std::clamp((g.levelScore * 100) / g.levelTarget, 0, 100);
}
inline std::string activePowerLabel(const GameSession& g) {
    std::string out;
    auto add = [&](const char* name, int frames) {
        if (frames <= 0) return;
        if (!out.empty()) out += "  ";
        out += name;
        out += ":";
        out += std::to_string((frames + 59) / 60);
        out += "s";
    };
    add("WIDE", g.powers.wideTimer);
    add("LASER", g.powers.laserTimer);
    add("SLOW", g.powers.slowTimer);
    add("SHIELD", g.powers.shieldTimer);
    add("CATCH", g.powers.catchTimer);
    add("FIRE", g.powers.fireTimer);
    add("GUN", g.powers.gunTimer);
    if (g.powers.extraBalls.size() > 0) {
        if (!out.empty()) out += "  ";
        out += "MULTI:" + std::to_string(g.powers.extraBalls.size());
    }
    return out.empty() ? "BONUS: NONE" : out;
}
}
