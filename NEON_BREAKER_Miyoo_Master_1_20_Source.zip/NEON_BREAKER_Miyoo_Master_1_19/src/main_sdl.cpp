#include "game_session.hpp"
#include "savegame.hpp"
#include "audio_engine.hpp"
#include "settings.hpp"
#include "input.hpp"
#include "hud.hpp"
#include "render_style.hpp"
#include "effects.hpp"
#include <SDL.h>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <cctype>
#include <utility>

namespace {
void audioCallback(void* userdata, Uint8* stream, int len){ auto* a=static_cast<nb::AudioEngine*>(userdata); if(!a||len<=0)return; a->render(reinterpret_cast<std::int16_t*>(stream),static_cast<std::size_t>(len)/(sizeof(std::int16_t)*2),22050); }
enum class Screen { Menu, Settings, Story, Play, Pause, GameOver, Clear, Ending };
void rect(SDL_Renderer* r,int x,int y,int w,int h,Uint8 cr,Uint8 cg,Uint8 cb){ SDL_Rect q{x,y,w,h}; SDL_SetRenderDrawColor(r,cr,cg,cb,255); SDL_RenderFillRect(r,&q); }
void outline(SDL_Renderer* r,int x,int y,int w,int h,Uint8 cr,Uint8 cg,Uint8 cb){ SDL_Rect q{x,y,w,h}; SDL_SetRenderDrawColor(r,cr,cg,cb,255); SDL_RenderDrawRect(r,&q); }
void circle(SDL_Renderer* r,int cx,int cy,int rad,Uint8 cr,Uint8 cg,Uint8 cb){ SDL_SetRenderDrawColor(r,cr,cg,cb,255); for(int y=-rad;y<=rad;++y) for(int x=-rad;x<=rad;++x) if(x*x+y*y<=rad*rad) SDL_RenderDrawPoint(r,cx+x,cy+y); }

std::string asciiText(std::string s){
 const std::pair<const char*,const char*> repl[]={
 {"á","a"},{"č","c"},{"ď","d"},{"é","e"},{"ě","e"},{"í","i"},{"ň","n"},{"ó","o"},{"ř","r"},{"š","s"},{"ť","t"},{"ú","u"},{"ů","u"},{"ý","y"},{"ž","z"},
 {"Á","A"},{"Č","C"},{"Ď","D"},{"É","E"},{"Ě","E"},{"Í","I"},{"Ň","N"},{"Ó","O"},{"Ř","R"},{"Š","S"},{"Ť","T"},{"Ú","U"},{"Ů","U"},{"Ý","Y"},{"Ž","Z"},{"„","\""},{"“","\""},{"—","-"},{"–","-"},{"…","..."},{"•","*"}};
 for(auto q:repl){std::string a=q.first;size_t pos=0;while((pos=s.find(a,pos))!=std::string::npos){s.replace(pos,a.size(),q.second);pos+=std::char_traits<char>::length(q.second);}}
 return s;
}
const char* glyph(char c){
 switch(c){
 case 'A':return "01110/10001/10001/11111/10001/10001/10001";case 'B':return "11110/10001/10001/11110/10001/10001/11110";case 'C':return "01111/10000/10000/10000/10000/10000/01111";case 'D':return "11110/10001/10001/10001/10001/10001/11110";case 'E':return "11111/10000/10000/11110/10000/10000/11111";case 'F':return "11111/10000/10000/11110/10000/10000/10000";case 'G':return "01111/10000/10000/10111/10001/10001/01111";case 'H':return "10001/10001/10001/11111/10001/10001/10001";case 'I':return "11111/00100/00100/00100/00100/00100/11111";case 'J':return "00111/00010/00010/00010/10010/10010/01100";case 'K':return "10001/10010/10100/11000/10100/10010/10001";case 'L':return "10000/10000/10000/10000/10000/10000/11111";case 'M':return "10001/11011/10101/10101/10001/10001/10001";case 'N':return "10001/11001/10101/10011/10001/10001/10001";case 'O':return "01110/10001/10001/10001/10001/10001/01110";case 'P':return "11110/10001/10001/11110/10000/10000/10000";case 'Q':return "01110/10001/10001/10001/10101/10010/01101";case 'R':return "11110/10001/10001/11110/10100/10010/10001";case 'S':return "01111/10000/10000/01110/00001/00001/11110";case 'T':return "11111/00100/00100/00100/00100/00100/00100";case 'U':return "10001/10001/10001/10001/10001/10001/01110";case 'V':return "10001/10001/10001/10001/10001/01010/00100";case 'W':return "10001/10001/10001/10101/10101/10101/01010";case 'X':return "10001/10001/01010/00100/01010/10001/10001";case 'Y':return "10001/10001/01010/00100/00100/00100/00100";case 'Z':return "11111/00001/00010/00100/01000/10000/11111";
 case '0':return "01110/10001/10011/10101/11001/10001/01110";case '1':return "00100/01100/00100/00100/00100/00100/01110";case '2':return "01110/10001/00001/00010/00100/01000/11111";case '3':return "11110/00001/00001/01110/00001/00001/11110";case '4':return "00010/00110/01010/10010/11111/00010/00010";case '5':return "11111/10000/10000/11110/00001/00001/11110";case '6':return "01110/10000/10000/11110/10001/10001/01110";case '7':return "11111/00001/00010/00100/01000/01000/01000";case '8':return "01110/10001/10001/01110/10001/10001/01110";case '9':return "01110/10001/10001/01111/00001/00001/01110";
 case '.':return "00000/00000/00000/00000/00000/00110/00110";case ',':return "00000/00000/00000/00000/00110/00110/00100";case ':':return "00000/00110/00110/00000/00110/00110/00000";case '!':return "00100/00100/00100/00100/00100/00000/00100";case '?':return "01110/10001/00001/00010/00100/00000/00100";case '-':return "00000/00000/00000/11111/00000/00000/00000";case '\'':return "00100/00100/00000/00000/00000/00000/00000";case '"':return "01010/01010/00000/00000/00000/00000/00000";case '/':return "00001/00010/00010/00100/01000/01000/10000";case '*':return "00000/10101/01110/11111/01110/10101/00000";case '(':return "00010/00100/01000/01000/01000/00100/00010";case ')':return "01000/00100/00010/00010/00010/00100/01000";case ' ':return "00000/00000/00000/00000/00000/00000/00000";default:return "00000/00000/00000/00000/00000/00000/00000";
 }
}
void drawText(SDL_Renderer* r,int x,int y,const std::string& raw,int scale,Uint8 cr=220,Uint8 cg=205,Uint8 cb=160){
 std::string t=asciiText(raw); SDL_SetRenderDrawColor(r,cr,cg,cb,255); int ox=x;
 for(char c:t){if(c=='\n'){y+=9*scale;x=ox;continue;} const char* pat=glyph((char)std::toupper((unsigned char)c));int row=0,col=0;for(const char* q=pat;*q;++q){if(*q=='/'){row++;col=0;continue;}if(*q=='1'){SDL_Rect z{x+col*scale,y+row*scale,scale,scale};SDL_RenderFillRect(r,&z);}col++;}x+=6*scale;}
}
std::vector<std::string> wrapText(const std::string& raw,int maxChars){std::string t=asciiText(raw);std::vector<std::string> out;std::string line,word;auto push=[&](){if(!line.empty()){out.push_back(line);line.clear();}};for(char c:t){if(c=='\n'){push();continue;}if(c==' '){if(line.size()+word.size()+1>(size_t)maxChars)push();if(!line.empty())line+=' ';line+=word;word.clear();}else word+=c;}if(!word.empty()){if(line.size()+word.size()+1>(size_t)maxChars)push();if(!line.empty())line+=' ';line+=word;}push();return out;}

void drawMiyooSidePanels(SDL_Renderer* r,const nb::GameSession& g,Screen s,const nb::AudioSettings& audioSettings){
 // The game remains in its native 400x700 portrait coordinate space. On the
 // 640x480 Miyoo display SDL letterboxes it to 274x480; use the two physical
 // side gutters for readable status and control hints instead of stretching it.
 SDL_RenderSetLogicalSize(r,0,0);
 rect(r,0,0,178,480,9,13,12); rect(r,462,0,178,480,9,13,12);
 rect(r,174,0,4,480,105,83,45); rect(r,462,0,4,480,105,83,45);
 outline(r,7,7,164,466,91,76,43); outline(r,469,7,164,466,91,76,43);
 drawText(r,20,24,"NEON",2,224,184,104); drawText(r,20,44,"BREAKER",2,224,184,104);
 drawText(r,20,92,"MIYOO",2,160,190,150); drawText(r,20,116,"640 X 480",1,170,175,150);
 drawText(r,20,166,"174 BPM",2,210,130,90);
 drawText(r,20,230,"OVLADANI",1,195,175,125);
 drawText(r,20,252,"D-PAD",2,225,210,170); drawText(r,20,278,"POHYB",1,175,185,160);
 drawText(r,20,320,"A = START",1,225,210,170); drawText(r,20,342,"START = PAUZA",1,175,185,160);
 drawText(r,20,404,"WIN98 / RAGGA",1,150,160,130);
 drawText(r,480,24,"STAV HRY",1,195,175,125);
 drawText(r,480,62,"LEVEL",1,175,185,160); drawText(r,480,82,nb::hudNumber(g.level,2),2,230,205,135);
 drawText(r,480,132,"SKORE",1,175,185,160); drawText(r,480,152,nb::hudNumber(g.score,7),2,230,205,135);
 drawText(r,480,202,"ZIVOTY",1,175,185,160); drawText(r,480,222,std::to_string(g.lives),2,230,205,135);
 drawText(r,480,274,"ZVUK",1,175,185,160);
 drawText(r,480,294,audioSettings.enabled?"ON":"OFF",2,audioSettings.enabled?100:210,audioSettings.enabled?210:120,120);
 drawText(r,480,340,"HLASITOST",1,175,185,160);
 drawText(r,480,360,std::to_string((int)(audioSettings.volume*100+0.5f))+"%",2,230,205,135);
 const char* state=s==Screen::Play?"HRA":s==Screen::Pause?"PAUZA":s==Screen::Story?"PRIBEH":s==Screen::Settings?"ZVUK":s==Screen::Menu?"MENU":"STAV";
 drawText(r,480,416,state,2,210,180,110);
 SDL_RenderSetLogicalSize(r,400,700);
}

void draw(SDL_Renderer* r,const nb::GameSession& g,Screen s,int menu,int scroll,int choice,const nb::AudioSettings& audioSettings,const std::vector<nb::Particle>& particles){
 SDL_SetRenderDrawColor(r,5,7,10,255); SDL_RenderClear(r);
 rect(r,8,8,384,684,13,17,14); outline(r,8,8,384,684,183,145,61);
 rect(r,18,24,364,28,23,35,24); outline(r,18,24,364,28,194,159,77);
 if(s==Screen::Settings){
  rect(r,42,145,316,390,20,23,17); outline(r,42,145,316,390,193,157,76);
  rect(r,72,174,256,38,194,159,77); drawText(r,112,187,"NASTAVENI ZVUKU",1,18,24,17);
  const std::string rows[3]={std::string("ZVUK: ")+(audioSettings.enabled?"ZAPNUTO":"VYPNUTO"),"HLASITOST: "+std::to_string((int)(audioSettings.volume*100+0.5f))+"%","ZPET DO MENU"};
  for(int i=0;i<3;i++){int y=260+i*70;bool selected=i==menu;rect(r,70,y,260,44,selected?104:48,selected?76:57,selected?37:42);outline(r,70,y,260,44,205,177,111);if(selected)rect(r,80,y+13,5,18,245,208,118);drawText(r,98,y+17,rows[i],1,selected?255:205,selected?225:198,selected?155:130);}
  drawText(r,72,495,"UP/DOWN: VYBER   LEFT/RIGHT: ZMENA",1,180,194,160);
  drawText(r,72,513,"A: PREPNOUT   START/ESC: ZPET",1,180,194,160);
  drawText(r,72,531,"NASTAVENI SE UKLADA AUTOMATICKY",1,180,194,160); return;
 }
 if(s==Screen::Menu || s==Screen::Pause || s==Screen::GameOver || s==Screen::Clear){
  const bool mainMenu=s==Screen::Menu; const int itemCount=mainMenu?5:4;
  rect(r,48,110,304,450,20,23,17); outline(r,48,110,304,450,193,157,76);
  rect(r,76,139,248,34,194,159,77);
  const char* heading = mainMenu ? "NEON BREAKER" : s==Screen::Pause ? "PAUZA" : s==Screen::GameOver ? "KONEC HRY" : "LEVEL HOTOV";
  drawText(r,92,151,heading,2,18,24,17);
  const char* mainItems[5]={"NOVA KAMPAN","POKRACOVAT","ULOZIT HRU","NASTAVENI ZVUKU","KONEC"};
  const char* pauseItems[4]={"POKRACOVAT","ULOZIT A MENU","RESTART LEVELU","HLAVNI MENU"};
  const char* overItems[4]={"ZKUSIT ZNOVU","ULOZIT SKORE","NOVA KAMPAN","HLAVNI MENU"};
  const char* clearItems[4]={"NOVA KAMPAN","ULOZIT HRU","POKRACOVAT","HLAVNI MENU"};
  const char** items=mainMenu?mainItems:s==Screen::Pause?pauseItems:s==Screen::GameOver?overItems:clearItems;
  for(int i=0;i<itemCount;i++){
   int y=(mainMenu?195:220)+i*(mainMenu?51:62); bool selected=i==menu;
   rect(r,82,y,236,38,selected?104:48,selected?76:57,selected?37:42);
   outline(r,82,y,236,38,205,177,111);
   if(selected) rect(r,91,y+11,5,16,245,208,118);
   drawText(r,108,y+14,items[i],1,selected?255:205,selected?225:198,selected?155:130);
  }
  drawText(r,85,493,"D-PAD: VYBER   A: POTVRDIT",1,180,194,160);
  drawText(r,85,510,"START: PAUZA / ZPET",1,180,194,160);
  drawText(r,85,527,"M: ZVUK   [ ]: HLASITOST",1,180,194,160);
  return;
 }
 if(s==Screen::Story){
  rect(r,18,24,364,28,23,35,24); drawText(r,28,31,"BORDEL / KAPITOLA "+std::to_string(g.level)+"/100",1,230,194,108);
  const auto& ch=g.story(); drawText(r,28,68,std::string(ch.title),2,230,194,108);
  std::string body="PRIJEM: BORDEL / KANAL 174.0\n\n"+std::string(ch.text);
  std::string branch=g.campaign.branchText(g.level); if(!branch.empty())body+="\n\n"+branch;
  const auto lines=wrapText(body,56); int y=112; const int first=std::clamp(scroll,0,std::max(0,(int)lines.size()-42));
  for(int i=first;i<(int)lines.size()&&i<first+42;i++,y+=10)drawText(r,28,y,lines[(size_t)i],1,207,204,184);
  rect(r,20,620,360,58,18,24,18); outline(r,20,620,360,58,183,145,61);
  bool decision=false; const nb::StoryDecision* d=nullptr;for(const auto& q:nb::campaignDecisions)if(q.chapter==g.level){decision=true;d=&q;break;}
  if(decision&&d){drawText(r,28,628,std::string(d->prompt),1,240,205,112);rect(r,28,644,164,26,choice==0?110:52,choice==0?78:50,35);rect(r,204,644,164,26,choice==1?110:52,choice==1?78:50,35);drawText(r,32,652,"A: "+std::string(d->optionA).substr(0,24),1);drawText(r,208,652,"B: "+std::string(d->optionB).substr(0,24),1);drawText(r,28,680,g.campaign.decisionSeen(g.level)?"VOLBA ULOZENA":"LEFT/RIGHT + A, POTOM START",1,180,200,170);}
  else drawText(r,28,646,"A / START: POKRACOVAT DO LEVELU",1,235,205,120);
  return;
 }
 if(s==Screen::Ending){rect(r,38,115,324,460,20,24,17);outline(r,38,115,324,460,194,159,77);drawText(r,62,145,"KONEC KAMPANE",2,235,200,105);drawText(r,62,185,g.campaign.endingTitle(),2,235,200,105);auto ls=wrapText(g.campaign.endingText(),43);int y=235;for(size_t i=0;i<ls.size()&&i<30;i++,y+=11)drawText(r,62,y,ls[i],1,220,214,184);drawText(r,62,535,"START: HLAVNI MENU",1,120,220,170);return;}
 // Playfield and status bar.
 rect(r,22,62,356,600,8,12,10); outline(r,22,62,356,600,107,91,53);
 for(const auto& p:particles){ const int a=nb::particleBrightness(p); const Uint8 cr=static_cast<Uint8>((int)p.color.r*a/255), cg=static_cast<Uint8>((int)p.color.g*a/255), cb=static_cast<Uint8>((int)p.color.b*a/255); circle(r,28+(int)p.x,70+(int)p.y,std::max(1,p.radius),cr,cg,cb); }
 for(const auto& b:g.layout.bricks){
  if(b.hp<=0) continue;
  const nb::Rgb face=nb::brickFaceColor(b.type,b.hp,b.maxHp);
  const nb::Rgb edge=nb::brickEdgeColor(b.type);
  const int x=28+b.x, y=70+b.y, w=std::max(1,b.w-2), h=std::max(1,b.h-2);
  rect(r,x,y,w,h,face.r,face.g,face.b);
  outline(r,x,y,w,h,edge.r,edge.g,edge.b);
  if(w>5 && h>4) rect(r,x+2,y+2,w-4,1,static_cast<Uint8>(std::min(255,(int)face.r+35)),static_cast<Uint8>(std::min(255,(int)face.g+35)),static_cast<Uint8>(std::min(255,(int)face.b+35)));
 }
 if(g.boss.active){ rect(r,28+(int)g.boss.x,70+(int)g.boss.y,(int)g.boss.w,(int)g.boss.h,151,53,42); outline(r,28+(int)g.boss.x,70+(int)g.boss.y,(int)g.boss.w,(int)g.boss.h,240,189,91); for(auto& sh:g.boss.shots) circle(r,28+(int)sh.x,70+(int)sh.y,(int)sh.r,222,64,48); }
 rect(r,28+(int)g.paddle.x,70+(int)g.paddle.y,(int)g.paddle.w,(int)g.paddle.h,205,177,111);
 if(g.paddle.w>8) rect(r,30+(int)g.paddle.x,71+(int)g.paddle.y,(int)g.paddle.w-4,2,255,235,184);
 if(g.ball.active){ circle(r,28+(int)g.ball.x,70+(int)g.ball.y,(int)g.ball.r+2,112,91,56); circle(r,28+(int)g.ball.x,70+(int)g.ball.y,(int)g.ball.r,245,238,204); }
 for(const auto& extra:g.powers.extraBalls){ circle(r,28+(int)extra.x,70+(int)extra.y,8,42,91,106); circle(r,28+(int)extra.x,70+(int)extra.y,6,135,235,250); }
 for(const auto& shot:g.powers.shots) rect(r,28+(int)shot.x-2,70+(int)shot.y-8,4,12,255,137,55);
 for(const auto& drop:g.falling){ Uint8 c=drop.type=='W'?90:drop.type=='R'?190:drop.type=='B'?80:210; rect(r,28+(int)drop.x-5,70+(int)drop.y-5,10,10,c,static_cast<Uint8>(c*.8),70); }
 // Miyoo-readable HUD: explicit score, lives, level and target progress.
 drawText(r,27,31,"LVL "+nb::hudNumber(g.level,2)+"  SCORE "+nb::hudNumber(g.score,7)+"  LIVES "+nb::hudNumber(g.lives,2),1,230,205,135);
 const int progress=nb::levelProgressPercent(g);
 rect(r,28,64,344,5,34,39,30); rect(r,28,64,344*progress/100,5,210,180,90);
 drawText(r,28,51,"TARGET "+nb::hudNumber(g.levelScore,6)+" / "+nb::hudNumber(g.levelTarget,6)+"  "+std::to_string(progress)+"%",1,185,190,160);
 if(g.boss.active){
  drawText(r,250,76,"BOSS HP "+std::to_string(g.boss.hp),1,245,120,90);
  rect(r,250,87,120,4,55,25,22); rect(r,250,87,std::min(120,g.boss.hp*4),4,220,65,48);
 }
 const std::string effects=nb::activePowerLabel(g);
 drawText(r,28,666,effects.substr(0,56),1,175,210,210);
 rect(r,28,684,110,4,194,159,77); rect(r,142,684,static_cast<int>(std::min(220,g.lives*30)),4,73,151,91);
}
}
int main(int argc,char** argv){
 (void)argc;(void)argv;
 if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_GAMECONTROLLER|SDL_INIT_EVENTS|SDL_INIT_AUDIO)!=0) return 2;
 nb::AudioEngine audio; nb::AudioSettings audioSettings; nb::loadAudioSettings(audioSettings,"neon_audio.cfg"); audio.setEnabled(audioSettings.enabled); audio.setVolume(audioSettings.volume); SDL_AudioSpec want{}; want.freq=22050; want.format=AUDIO_S16SYS; want.channels=2; want.samples=512; want.callback=audioCallback; want.userdata=&audio; SDL_AudioDeviceID audioDevice=SDL_OpenAudioDevice(nullptr,0,&want,nullptr,0); if(audioDevice) SDL_PauseAudioDevice(audioDevice,0);
 SDL_Window* win=SDL_CreateWindow("NEON BREAKER",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,640,480,SDL_WINDOW_SHOWN);
 if(!win){SDL_Quit();return 3;}
 SDL_Renderer* ren=SDL_CreateRenderer(win,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
 if(!ren){SDL_DestroyWindow(win);SDL_Quit();return 4;}
 SDL_RenderSetLogicalSize(ren,400,700);
 SDL_GameController* pad=nullptr; for(int i=0;i<SDL_NumJoysticks();++i) if(SDL_IsGameController(i)){pad=SDL_GameControllerOpen(i);if(pad)break;}
 nb::GameSession game; game.beginLevel(1); Screen screen=Screen::Menu; int menu=0,storyScroll=0,storyChoice=0; bool quit=false,launch=false; double target=200; std::vector<nb::Particle> particles; std::uint32_t effectSeed=1;
 while(!quit){ SDL_Event e; while(SDL_PollEvent(&e)){
  if(e.type==SDL_QUIT) quit=true;
  if(e.type==SDL_CONTROLLERDEVICEADDED && !pad){ pad=SDL_GameControllerOpen(e.cdevice.which); }
  if(e.type==SDL_CONTROLLERDEVICEREMOVED && pad && SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(pad))==e.cdevice.which){ SDL_GameControllerClose(pad); pad=nullptr; }
  if(e.type==SDL_KEYDOWN){ SDL_Keycode k=e.key.keysym.sym;
   if(k==SDLK_m){audio.setEnabled(!audio.enabled()); audioSettings.enabled=audio.enabled(); nb::saveAudioSettings(audioSettings,"neon_audio.cfg");} if(k==SDLK_LEFTBRACKET){audio.setVolume(audio.volume()-0.05f);audioSettings.volume=audio.volume();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");} if(k==SDLK_RIGHTBRACKET){audio.setVolume(audio.volume()+0.05f);audioSettings.volume=audio.volume();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");}
   if(k==SDLK_ESCAPE||k==SDLK_p){ if(screen==Screen::Play)screen=Screen::Pause;else if(screen==Screen::Pause)screen=Screen::Play;else if(screen==Screen::Settings){screen=Screen::Menu;menu=0;}else if(screen==Screen::Menu)quit=true; }
   if(screen==Screen::Story){ if(k==SDLK_UP)storyScroll=std::max(0,storyScroll-3); if(k==SDLK_DOWN)storyScroll+=3; if(k==SDLK_LEFT||k==SDLK_RIGHT)storyChoice=1-storyChoice; if(k==SDLK_a||k==SDLK_RETURN||k==SDLK_SPACE)launch=true; }
   if(screen==Screen::Play){if(k==SDLK_LEFT||k==SDLK_a) target-=24; if(k==SDLK_RIGHT||k==SDLK_d) target+=24;}
   if(screen==Screen::Settings){ if(k==SDLK_UP)menu=(menu+2)%3; if(k==SDLK_DOWN)menu=(menu+1)%3; if(k==SDLK_LEFT||k==SDLK_RIGHT||k==SDLK_RETURN||k==SDLK_SPACE){ if(menu==0){audio.setEnabled(!audio.enabled());audioSettings.enabled=audio.enabled();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");}else if(menu==1){float v=audioSettings.volume+(k==SDLK_LEFT?-0.05f:0.05f);audio.setVolume(v);audioSettings.volume=audio.volume();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");}else{screen=Screen::Menu;menu=0;} } }
   if(screen==Screen::Menu||screen==Screen::Pause||screen==Screen::GameOver||screen==Screen::Clear||screen==Screen::Ending){ int count=screen==Screen::Menu?5:4; if(k==SDLK_UP)menu=(menu+count-1)%count; if(k==SDLK_DOWN)menu=(menu+1)%count; if(k==SDLK_RETURN||k==SDLK_SPACE)launch=true; }
   if(k==SDLK_SPACE&&screen==Screen::Play&&!game.ball.active){game.ball.active=true;game.ball.x=game.paddle.x+game.paddle.w/2;game.ball.y=game.paddle.y-10;game.ball.vx=2.2;game.ball.vy=-5.6;}
  }
  if(e.type==SDL_CONTROLLERAXISMOTION&&e.caxis.axis==SDL_CONTROLLER_AXIS_LEFTX) target=nb::paddleTargetFromAxis(e.caxis.value);
  if(e.type==SDL_CONTROLLERBUTTONDOWN){
   const bool menuScreen=screen==Screen::Menu||screen==Screen::Pause||screen==Screen::GameOver||screen==Screen::Clear||screen==Screen::Ending;
   if(e.cbutton.button==SDL_CONTROLLER_BUTTON_START){if(screen==Screen::Play)screen=Screen::Pause;else if(screen==Screen::Pause)screen=Screen::Play;else if(screen==Screen::Settings){screen=Screen::Menu;menu=0;}else launch=true;}
   if(e.cbutton.button==SDL_CONTROLLER_BUTTON_LEFTSHOULDER){audio.setVolume(audio.volume()-0.05f);audioSettings.volume=audio.volume();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");}
   if(e.cbutton.button==SDL_CONTROLLER_BUTTON_RIGHTSHOULDER){audio.setVolume(audio.volume()+0.05f);audioSettings.volume=audio.volume();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");}
   if(screen==Screen::Story){if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_UP)storyScroll=std::max(0,storyScroll-3);if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_DOWN)storyScroll+=3;if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_LEFT||e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_RIGHT)storyChoice=1-storyChoice;if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A)launch=true;}
   if(screen==Screen::Settings){if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_UP)menu=(menu+2)%3;if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_DOWN)menu=(menu+1)%3;if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_LEFT||e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_RIGHT||e.cbutton.button==SDL_CONTROLLER_BUTTON_A){if(menu==0){audio.setEnabled(!audio.enabled());audioSettings.enabled=audio.enabled();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");}else if(menu==1){audio.setVolume(audio.volume()+(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_LEFT?-0.05f:0.05f));audioSettings.volume=audio.volume();nb::saveAudioSettings(audioSettings,"neon_audio.cfg");}else{screen=Screen::Menu;menu=0;}}}
   if(menuScreen){int count=screen==Screen::Menu?5:4;if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_UP)menu=(menu+count-1)%count;if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_DOWN)menu=(menu+1)%count;if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A)launch=true;}
   if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_LEFT&&screen==Screen::Play)target-=24;
   if(e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_RIGHT&&screen==Screen::Play)target+=24;
   if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A&&screen==Screen::Play&&!game.ball.active){game.ball.active=true;game.ball.x=game.paddle.x+game.paddle.w/2;game.ball.y=game.paddle.y-10;game.ball.vy=-5.6;}
  }
 }
 if(launch){launch=false; if(screen==Screen::Menu){if(menu==0){game=nb::GameSession{};game.beginLevel(1);storyScroll=0;screen=Screen::Story;}else if(menu==1){if(nb::loadGame(game,"neon_breaker.sav"))screen=game.campaignMode?Screen::Story:Screen::Play;}else if(menu==2){nb::saveGame(game,"neon_breaker.sav");}else if(menu==3){screen=Screen::Settings;menu=0;}else quit=true;}else if(screen==Screen::Pause){if(menu==0)screen=Screen::Play;else if(menu==1){nb::saveGame(game,"neon_breaker.sav");screen=Screen::Menu;}else if(menu==2){game=nb::GameSession{};game.beginLevel(1);screen=Screen::Play;}else screen=Screen::Menu;}else if(screen==Screen::Story){ bool hasDecision=false;for(const auto& d:nb::campaignDecisions)if(d.chapter==game.level)hasDecision=true; if(hasDecision&&!game.campaign.decisionSeen(game.level)){game.chooseStory(game.level,storyChoice==0);nb::saveGame(game,"neon_breaker.sav");} game.campaignMode=true;game.ball.active=true;game.ball.x=game.paddle.x+game.paddle.w/2;game.ball.y=game.paddle.y-10;game.ball.vx=2.2;game.ball.vy=-5.6;screen=Screen::Play;storyScroll=0;nb::saveGame(game,"neon_breaker.sav"); }else if(screen==Screen::Ending){screen=Screen::Menu;}else if(screen==Screen::GameOver){
  if(menu==0){game=nb::GameSession{};game.beginLevel(1);screen=Screen::Story;}
  else if(menu==1){nb::saveGame(game,"neon_breaker.sav");screen=Screen::Menu;}
  else if(menu==2){game=nb::GameSession{};game.beginLevel(1);screen=Screen::Story;}
  else screen=Screen::Menu;
 }else if(screen==Screen::Clear){
  if(menu==0){game=nb::GameSession{};game.beginLevel(1);screen=Screen::Story;}
  else if(menu==1){nb::saveGame(game,"neon_breaker.sav");screen=Screen::Menu;}
  else if(menu==2){game=nb::GameSession{};game.beginLevel(1);screen=Screen::Story;}
  else screen=Screen::Menu;
 } menu=0; }
 audio.setGameplay(screen==Screen::Play);
 if(screen==Screen::Play){
  const double oldBallVy=game.ball.vy; const int oldBossHp=game.boss.hp;
  const std::size_t oldFalling=game.falling.size();
  auto pr=game.tick(std::clamp(target,0.0,400.0));
  if(pr.bricksDamaged>0){audio.triggerBrick(); auto burst=nb::particleBurst(game.ball.x,game.ball.y,std::min(18,pr.bricksDamaged*6),{235,178,83},effectSeed++); particles.insert(particles.end(),burst.begin(),burst.end()); if(particles.size()>160) particles.erase(particles.begin(),particles.begin()+(particles.size()-160));}
  if(oldBallVy>0.0 && game.ball.vy<0.0 && game.ball.active)audio.triggerPaddle();
  if(game.falling.size()<oldFalling)audio.triggerPower();
  if(oldBossHp>game.boss.hp){audio.triggerBrick(); auto burst=nb::particleBurst(game.boss.x+game.boss.w/2,game.boss.y+game.boss.h/2,24,{255,86,58},effectSeed++); particles.insert(particles.end(),burst.begin(),burst.end()); if(particles.size()>160) particles.erase(particles.begin(),particles.begin()+(particles.size()-160));}
  if(pr.lostBall&&game.gameOver)screen=Screen::GameOver; if(game.cleared()){ if(game.level<100){ const int next=game.level+1; game.beginLevel(next); storyScroll=0;storyChoice=0; screen=game.campaignMode?Screen::Story:Screen::Play; } else screen=game.campaignMode?Screen::Ending:Screen::Clear; } }
 nb::updateParticles(particles,1.0f);
 draw(ren,game,screen,menu,storyScroll,storyChoice,audioSettings,particles); drawMiyooSidePanels(ren,game,screen,audioSettings); SDL_RenderPresent(ren);
 }
 if(audioDevice)SDL_CloseAudioDevice(audioDevice); if(pad)SDL_GameControllerClose(pad); SDL_DestroyRenderer(ren);SDL_DestroyWindow(win);SDL_Quit();return 0;
}
