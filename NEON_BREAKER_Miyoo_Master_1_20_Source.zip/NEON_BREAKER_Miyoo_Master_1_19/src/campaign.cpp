#include "campaign.hpp"
#include <algorithm>
namespace nb {
static int decisionIndex(int chapter){ switch(chapter){case 29:return 0;case 45:return 1;case 59:return 2;case 76:return 3;case 83:return 4;case 92:return 5;default:return -1;} }
bool CampaignState::decisionSeen(int chapter) const { int i=decisionIndex(chapter); return i>=0 && seen[static_cast<std::size_t>(i)]; }
bool CampaignState::applyDecision(int chapter,bool optionA){
 int idx=decisionIndex(chapter); if(idx<0||seen[static_cast<std::size_t>(idx)]) return false;
 const StoryDecision* d=nullptr; for(const auto& q:campaignDecisions) if(q.chapter==chapter){d=&q;break;} if(!d)return false;
 const int a[7]={d->dealerA,d->radioA,d->trustA,d->evidenceA,d->crewA,d->plantA,d->aiA};
 const int b[7]={d->dealerB,d->radioB,d->trustB,d->evidenceB,d->crewB,d->plantB,d->aiB};
 for(int i=0;i<7;i++) values[i]=std::clamp(values[i]+(optionA?a[i]:b[i]),-2,6);
 seen[static_cast<std::size_t>(idx)]=true; return true;
}
std::string CampaignState::branchText(int chapter) const {
 if(chapter%5!=0 && chapter!=46 && chapter!=60 && chapter!=77 && chapter!=84 && chapter!=93) return {};
 const auto& c=values; std::string o;
 auto add=[&](const char* s){if(!o.empty())o+="\n\n";o+=s;};
 if(chapter>=30)add(c[0]>=2?"PAŠERÁCKÁ VĚTEV: Lojza dodržel dohodu. Pašeráci ti otevřeli servisní koridor a jejich hlídky tě kryjí.":"PAŠERÁCKÁ VĚTEV: Lojza odmítl riskovat kvůli tobě. Koridor hlídá podsvětí a musíš projít přes zabezpečení BORDELU.");
 if(chapter>=46)add(c[2]>=2?"VĚTEV STARÉ AI: AI ti důvěřuje a odemyká staré servisní záznamy. Přizná, že tě z BORDELU odvezla proti tvé vůli, aby tě zachránila.":c[2]<=-1?"VĚTEV STARÉ AI: AI ti zatajila část minulosti. Protože jsi jí omezil přístup, musíš tajemství laboratoře hledat bez její pomoci.":"VĚTEV STARÉ AI: Váš vztah zůstává nejistý. AI pomáhá, ale nejdůležitější záznam si nechává pro sebe.");
 if(chapter>=60)add(c[4]>=2?"VĚTEV POSÁDKY: Zachránění lidé se přidali k posádce. V laboratoři připravují bezpečné množení vzorku.":"VĚTEV ARCHIVU: Vědecký tým se nepodařilo zachránit. Máš ale důkazy o Velkém vyschnutí a víš, kdo vydal rozkaz.");
 if(chapter>=77)add(c[1]>=2?"VĚTEV RÁDIA: Bassová Svině FM odvysílala Tichounovu minulost. Část jeho jednotek odmítá dál poslouchat rozkazy.":"VĚTEV TICHÉHO VYSÍLÁNÍ: Pravda zůstala utajená. Generál Ticho má stále podporu a jeho obrana je silnější.");
 if(chapter>=84)add(c[5]>=2?"VĚTEV ROSTLINY: Vzorek je připraven k obnově a chrání ho spojenci.":"VĚTEV TAJNÉHO TREZORU: Vzorek zůstává skrytý. Je v bezpečí, ale jeho obnova bude obtížná.");
 if(chapter>=93)add(c[6]>=2?"FINÁLNÍ VĚTEV: STARÁ AI přebírá řízení obranné sítě. Může ti otevřít cestu k Tichounovi, ale její vlastní plán zůstává nejasný.":c[6]<=-1?"FINÁLNÍ VĚTEV: STARÁ AI je odpojena od trezoru. Závěrečný souboj musíš zvládnout bez jejího zásahu.":"FINÁLNÍ VĚTEV: STARÁ AI ti pomáhá jen v omezeném režimu. O výsledku rozhodnou spojenci a důkazy.");
 return o;
}
std::string CampaignState::endingTitle() const {
 const auto& c=values; const bool allies=c[0]>=2&&c[4]>=1, truth=c[1]>=2&&c[3]>=2, green=c[5]>=2&&c[4]>=1;
 if(c[2]<=-1&&c[6]>=1)return "Zrada STARE AI";
 if(green&&truth&&allies)return "Zelený ráj";
 if(c[5]<=0&&c[0]>=2)return "Král pašeráků";
 if(c[5]>=2&&c[4]<=0)return "Vesmírná katastrofa";
 if(c[2]>=2&&c[5]>=1&&c[6]>=0)return "Posledni joint";
 if(truth&&c[1]>=2)return "174 BPM";
 return "Posledni joint";
}
std::string CampaignState::endingText() const {
 const auto t=endingTitle();
 if(t=="Zrada STARE AI")return "STARA AI odhali, ze po celou dobu planovala prevzit biologicky trezor. Nechtela rostlinu znicit, ale rozhodnout o ni sama – protoze uz neveri lidem ani SROT-7ovi. Pokud mas spojence, pomohou ti ji zastavit. Pokud ne, AI odleti se vzorkem a galaxie zustane v nejistote.";
 if(t=="Zelený ráj")return "Diky spojencum, odvysilane pravde a zachranenym vedeckym datum se posledni rostlina bezpecne rozmnozi. CISTY DECH padne a General Ticho ztrati moc. Galaxie obnovuje sve ekosystemy i hudbu. SROT-7 odmitne cestne misto ve vlade a vraci se opravovat aparaturu.";
 if(t=="Král pašeráků")return "SROT-7 preda vzorek paseracke siti. Lojza a Kral paseraku ovladnou distribuci a SROT-7 se stane nejmocnejsim clovekem podsveti. Rostlina prezije, ale misto svobody vznikne novy monopol. General Ticho padne, jeho uniformu nahradi drazsi oblek.";
 if(t=="Vesmírná katastrofa")return "Vzorek se dostane do nekontrolovaneho prostredi bez vedcu a ochranneho planu. Rostlina se rozsiri rychleji, nez kdokoli cekal. Mesta zarostou a galaxie se rozdeli na ty, kteri tomu rikaji zazrak, a ty, kteri volaji po deratizaci.";
 if(t=="174 BPM")return "Tajny konec: pravda o DJ Tichounovi se dostane do eteru presne ve chvili, kdy se podari obejit jeho cenzuru. Bassova Svine FM prevezme vysilaci sit CISTEHO DECHU a cela galaxie uslysi 174 BPM. Ticho je porazen a musi moderovat nocni porad s tracky, ktere kdysi zakazoval.";
 return "STARA AI a SROT-7 uzavrou nouzove spojenectvi. Nemaji dost lidi, dat ani vlivu na obnovu cele galaxie, ale dokazou uchranit posledni vzorek v malem trezoru. SROT-7 zustane hlidat jeho generator a AI poprve prestane predstirat, ze ji na nem nezalezi. Pust jim aspon jeden poradny bassline.";
}
}
