#include "powerups.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace nb {
const std::array<char,12>& powerTypes(){ static const std::array<char,12> t={'W','R','Z','F','C','G','L','B','T','P','M','S'}; return t; }
namespace { uint32_t nextRandom(uint32_t& state){ state=state*1664525u+1013904223u; return state; } }
bool rollPowerDrop(uint32_t& state){ return (nextRandom(state)>>8) < static_cast<uint32_t>(0.28*16777216.0); }
char choosePowerType(uint32_t& state){ const auto& t=powerTypes(); return t[nextRandom(state)%t.size()]; }
void tickPowerTimers(PowerState& s,double base){
 if(s.weaponCooldown>0)--s.weaponCooldown;
 if(s.wideTimer>0 && --s.wideTimer==0) s.paddleWidth=base;
 if(s.laserTimer>0)--s.laserTimer;
 if(s.slowTimer>0)--s.slowTimer;
 if(s.shieldTimer>0)--s.shieldTimer;
 if(s.catchTimer>0)--s.catchTimer;
 if(s.fireTimer>0)--s.fireTimer;
 if(s.gunTimer>0)--s.gunTimer;
}
void collectPower(PowerState& s,PowerBall& ball,char t){
 switch(t){
 case 'W': s.paddleWidth=112; s.wideTimer=720; break;
 case 'R': s.paddleWidth=48; s.wideTimer=600; break;
 case 'M': s.score+=500; break;
 case 'B': s.lives=std::min(9,s.lives+1); break;
 case 'T': { double base=std::clamp(std::hypot(ball.vx,ball.vy),4.8,8.5); int slots=std::max(0,4-(int)s.extraBalls.size()); int split=std::min(2,slots); double side=std::min(5.5,base*.8), vertical=std::sqrt(std::max(1.0,base*base-side*side)); if(split>0)s.extraBalls.push_back({ball.x-9,ball.y,-side,-vertical,false}); if(split>1)s.extraBalls.push_back({ball.x+9,ball.y,side,-vertical,false}); break; }
 case 'L': s.laserTimer=720; s.gunTimer=0; break;
 case 'G': s.gunTimer=720; s.laserTimer=0; break;
 case 'S': s.shieldTimer=720; break;
 case 'Z': s.slowTimer=600; break;
 case 'F': { s.slowTimer=0; auto speed=[](PowerBall& b){double v=std::hypot(b.vx,b.vy);if(v>0){double n=std::min(8.5,std::max(4.8,v*1.35));b.vx=b.vx/v*n;b.vy=b.vy/v*n;}}; speed(ball); for(auto& b:s.extraBalls)speed(b); break; }
 case 'C': s.catchTimer=600; break;
 case 'P': s.fireTimer=720; ball.fire=true; break;
 default: return;
 }
 s.score+=50;
}
}
