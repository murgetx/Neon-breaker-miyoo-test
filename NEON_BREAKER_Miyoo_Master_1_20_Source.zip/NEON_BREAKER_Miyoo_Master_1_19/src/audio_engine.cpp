#include "audio_engine.hpp"
#include <algorithm>
#include <cmath>

namespace nb {
namespace { constexpr double pi = 3.14159265358979323846; }
void AudioEngine::setVolume(float v) noexcept { volume_ = std::clamp(v, 0.0f, 1.0f); }
void AudioEngine::render(std::int16_t* out, std::size_t frames, int rate) noexcept {
    if (!out || rate <= 0) return;
    const double beat = static_cast<double>(rate) * 60.0 / 174.0;
    for (std::size_t i=0; i<frames; ++i, ++sample_) {
        float s = 0.0f;
        if (enabled_ && volume_ > 0.0f) {
            const double inBeat = std::fmod(static_cast<double>(sample_), beat);
            const int step = static_cast<int>(sample_ / (beat * 0.5)) % 8;
            // 174 BPM jungle pulse: kick on beats, snare on the backbeat, shuffled hats.
            if (inBeat < rate * 0.105 && (step == 0 || step == 4)) {
                const double t = inBeat / (rate * 0.105);
                const double f = 92.0 - 48.0*t;
                s += static_cast<float>(std::sin(2*pi*f*inBeat/rate) * (1.0-t) * 0.62);
            }
            if (inBeat < rate * 0.075 && (step == 2 || step == 6)) {
                noise_ ^= noise_ << 13; noise_ ^= noise_ >> 17; noise_ ^= noise_ << 5;
                const float n = (static_cast<float>(noise_ & 0xffffu)/32767.5f)-1.0f;
                const double t = inBeat/(rate*0.075);
                s += n * static_cast<float>((1.0-t)*0.20);
            }
            const double half = std::fmod(static_cast<double>(sample_), beat*0.5);
            if (half < rate*0.018) {
                noise_ ^= noise_ << 13; noise_ ^= noise_ >> 17; noise_ ^= noise_ << 5;
                const float n = (static_cast<float>(noise_ & 0xffffu)/32767.5f)-1.0f;
                s += n * static_cast<float>(1.0-half/(rate*0.018))*0.055f;
            }
            const double bpmHz = 174.0/60.0;
            bassPhase_ += 2*pi*(gameplay_ ? 55.0 : 41.2)/rate;
            const double bassEnv = 0.5 + 0.5*std::sin(2*pi*bpmHz*static_cast<double>(sample_)/rate);
            s += static_cast<float>(std::sin(bassPhase_) * bassEnv * (gameplay_ ? 0.105 : 0.055));
            auto fx = [&](float& env, double freq, float amp) { if(env>0.0005f){ s += static_cast<float>(std::sin(phase_+freq*static_cast<double>(sample_)/rate*2*pi)*env*amp); env*=0.985f; } };
            fx(paddleClick_, 880.0, 0.20f); fx(brickClick_, 440.0, 0.25f); fx(powerClick_, 1320.0, 0.28f);
            s *= volume_;
        }
        const auto v = static_cast<std::int16_t>(std::clamp(s, -0.92f, 0.92f)*32767.0f);
        out[i*2] = v; out[i*2+1] = v;
    }
}
}
