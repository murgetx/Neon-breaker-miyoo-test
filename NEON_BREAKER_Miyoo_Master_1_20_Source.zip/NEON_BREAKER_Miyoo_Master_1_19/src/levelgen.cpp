#include "levelgen.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <set>
#include <utility>
#include <vector>

namespace nb {
namespace {
struct Candidate { int row, col; double rank; };
}
LevelLayout buildLevel(int level) {
    if (level < 1) level = 1;
    constexpr int cols=20, rows=8, brickW=18, brickH=12;
    constexpr int gapX=2, gapY=2, startX=1, startY=132;
    uint32_t seed = static_cast<uint32_t>(static_cast<uint64_t>(level) * 2654435761ULL);
    auto rand01 = [&seed]() -> double {
        seed = seed * 1664525u + 1013904223u;
        return static_cast<double>(seed) / 4294967296.0;
    };
    std::vector<Candidate> candidates;
    candidates.reserve(rows * (cols/2));
    for (int r=0; r<rows; ++r) {
        for (int c=0; c<cols/2; ++c) {
            const double rowBias=(rows-1-r)*0.075;
            candidates.push_back({r,c,rand01()+rowBias});
        }
    }
    // JS Array.sort is stable in modern engines; preserve insertion order for ties.
    std::stable_sort(candidates.begin(), candidates.end(),
        [](const Candidate& a,const Candidate& b){ return a.rank>b.rank; });
    const int targetPairs=std::min(76,22+static_cast<int>(std::floor((level-1)*0.55)));
    std::set<std::pair<int,int>> selected;
    for (int i=0; i<targetPairs; ++i)
        selected.insert({candidates[i].row,candidates[i].col});
    const int hpBand=1+static_cast<int>(std::floor((level-1)/25.0));
    LevelLayout out{level,targetPairs,hpBand,{}};
    out.bricks.reserve(targetPairs*2);
    for (int r=0; r<rows; ++r) for (int c=0; c<cols/2; ++c) {
        if (!selected.count({r,c})) continue;
        for (int mirror : {c,cols-1-c}) {
            const int x=startX+mirror*(brickW+gapX);
            const int y=startY+r*(brickH+gapY);
            out.bricks.push_back({x,y,brickW,brickH,hpBand,hpBand,r,mirror});
        }
    }
    return out;
}
}
