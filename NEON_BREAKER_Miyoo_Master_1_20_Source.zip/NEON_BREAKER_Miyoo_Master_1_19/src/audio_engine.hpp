#pragma once
#include <cstddef>
#include <cstdint>

namespace nb {
// Lightweight procedural stereo audio. No SDL_mixer or external assets required.
class AudioEngine {
public:
    void setEnabled(bool enabled) noexcept { enabled_ = enabled; }
    bool enabled() const noexcept { return enabled_; }
    void setVolume(float volume) noexcept;
    float volume() const noexcept { return volume_; }
    void setGameplay(bool gameplay) noexcept { gameplay_ = gameplay; }
    void triggerPaddle() noexcept { paddleClick_ = 1.0f; }
    void triggerBrick() noexcept { brickClick_ = 1.0f; }
    void triggerPower() noexcept { powerClick_ = 1.0f; }
    void render(std::int16_t* output, std::size_t frames, int sampleRate) noexcept;
private:
    bool enabled_ = true;
    bool gameplay_ = false;
    float volume_ = 0.55f;
    double phase_ = 0.0;
    double bassPhase_ = 0.0;
    double hatPhase_ = 0.0;
    std::uint32_t noise_ = 0x4E425231u;
    float paddleClick_ = 0.0f, brickClick_ = 0.0f, powerClick_ = 0.0f;
    std::uint64_t sample_ = 0;
};
}
