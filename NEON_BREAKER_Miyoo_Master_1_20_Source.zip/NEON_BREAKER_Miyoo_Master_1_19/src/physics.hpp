#pragma once
#include "levelgen.hpp"
#include <vector>
#include <utility>
namespace nb {
struct Ball { double x=200,y=610,vx=2.0,vy=-5.8; double r=7; bool active=true; };
struct Paddle { double x=165,y=650,w=70,h=10; };
struct PhysicsResult { int bricksDamaged=0, bricksDestroyed=0, scoreAward=0; bool lostBall=false; std::vector<std::pair<double,double>> destroyedAt; };
// Frame-based arcade physics ported from source moveOneBall/hitBrick behavior.
PhysicsResult stepPhysics(Ball& ball, Paddle& paddle, std::vector<Brick>& bricks, double paddleTargetX);
}
