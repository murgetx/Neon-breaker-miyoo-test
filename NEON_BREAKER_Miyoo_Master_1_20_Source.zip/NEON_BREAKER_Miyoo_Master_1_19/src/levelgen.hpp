#pragma once
#include <cstdint>
#include <vector>

namespace nb {
enum class BrickType : uint8_t { Normal, Steel, Gold, Explosive, Regen, Moving };
struct Brick {
    int x, y, w, h;
    int hp, maxHp;
    int row, col;
    BrickType type=BrickType::Normal;
    float baseX=0.0f, phase=0.0f, regenClock=0.0f;
};
struct LevelLayout {
    int level;
    int targetPairs;
    int brickHp;
    std::vector<Brick> bricks;
};
// Faithful port of the source HTML's LCG-based, mirrored 20x8 level generator.
LevelLayout buildLevel(int level);
}
