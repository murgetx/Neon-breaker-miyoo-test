#pragma once
#include <array>
#include <string>
#include "campaign_data.hpp"
namespace nb {
struct CampaignState {
 std::array<int,7> values{}; // dealer, radio, trust, evidence, crew, plant, aiControl
 std::array<bool,6> seen{};
 bool applyDecision(int chapter, bool optionA);
 bool decisionSeen(int chapter) const;
 std::string branchText(int chapter) const;
 std::string endingTitle() const;
 std::string endingText() const;
};
}
