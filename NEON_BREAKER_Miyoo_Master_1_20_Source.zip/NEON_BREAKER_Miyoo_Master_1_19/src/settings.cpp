#include "settings.hpp"
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <string>
namespace nb {
bool loadAudioSettings(AudioSettings& settings, const std::string& path) noexcept {
 try {
  std::ifstream in(path); if(!in) return false;
  std::string magic; int version=0, enabled=1; float volume=0.55f;
  if(!(in>>magic>>version>>enabled>>volume) || magic!="NEON_AUDIO" || version!=1 || (enabled!=0&&enabled!=1) || volume<0.0f || volume>1.0f) return false;
  std::string extra; if(in>>extra) return false;
  settings.enabled=enabled!=0; settings.volume=volume; return true;
 } catch(...) { return false; }
}
bool saveAudioSettings(const AudioSettings& settings, const std::string& path) noexcept {
 try {
  if(path.empty() || settings.volume<0.0f || settings.volume>1.0f) return false;
  const std::string tmp=path+".tmp", bak=path+".bak";
  { std::ofstream out(tmp,std::ios::trunc); if(!out) return false; out<<"NEON_AUDIO 1 "<<(settings.enabled?1:0)<<' '<<settings.volume<<'\n'; out.flush(); if(!out){out.close();std::remove(tmp.c_str());return false;} }
  std::remove(bak.c_str());
  const bool hadOld=std::rename(path.c_str(),bak.c_str())==0;
  if(std::rename(tmp.c_str(),path.c_str())!=0){ if(hadOld)std::rename(bak.c_str(),path.c_str());std::remove(tmp.c_str());return false; }
  return true;
 } catch(...) { return false; }
}
}
