#pragma once
#include "render_style.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace nb {
struct Particle {
    float x=0, y=0, vx=0, vy=0;
    int life=0, maxLife=1, radius=1;
    Rgb color{220,180,100};
};
inline std::vector<Particle> particleBurst(float x,float y,int count,Rgb color,std::uint32_t seed=1) {
    std::vector<Particle> out;
    count=std::clamp(count,0,48);
    std::uint32_t state=seed?seed:1;
    auto next=[&](){ state^=state<<13; state^=state>>17; state^=state<<5; return state; };
    for(int i=0;i<count;++i){
        const float angle=(static_cast<float>(next()%6284)/1000.0f);
        const float speed=0.65f+static_cast<float>(next()%240)/100.0f;
        const int life=14+static_cast<int>(next()%19);
        Particle p; p.x=x; p.y=y; p.vx=std::cos(angle)*speed; p.vy=std::sin(angle)*speed;
        p.life=life; p.maxLife=life; p.radius=1+static_cast<int>(next()%2); p.color=color; out.push_back(p);
    }
    return out;
}
inline void updateParticles(std::vector<Particle>& particles,float dt=1.0f) {
    dt=std::clamp(dt,0.0f,3.0f);
    for(auto& p:particles){ p.x+=p.vx*dt; p.y+=p.vy*dt; p.vy+=0.035f*dt; p.vx*=0.985f; p.life-=static_cast<int>(std::max(1.0f,dt)); }
    particles.erase(std::remove_if(particles.begin(),particles.end(),[](const Particle& p){return p.life<=0;}),particles.end());
}
inline int particleBrightness(const Particle& p) { return p.maxLife>0?std::clamp(p.life*255/p.maxLife,0,255):0; }
}
