#pragma once
#include <array>
#include <string>
#include <vector>
#include <cstdint>
namespace nb {
struct PowerBall { double x=200,y=610,vx=0,vy=-5.8; bool fire=false; };
struct FallingPower { double x=0,y=0,vy=1.8; char type='M'; bool collected=false; };
struct PowerShot { double x=0,y=0; int damage=1; double speed=7.0; };
struct PowerState {
 double paddleWidth=70; int lives=3; int score=0;
 int wideTimer=0, laserTimer=0, slowTimer=0, shieldTimer=0, catchTimer=0, fireTimer=0, gunTimer=0;
 std::vector<PowerBall> extraBalls;
 std::vector<PowerShot> shots; int weaponCooldown=0;
};
// Source-faithful collection effects and frame timers from v11.9.9.
void tickPowerTimers(PowerState& state, double basePaddleWidth=70);
void collectPower(PowerState& state, PowerBall& mainBall, char type);
const std::array<char,12>& powerTypes();
// Original v11.9.9 drop probability: 28% per destroyed brick.
bool rollPowerDrop(uint32_t& state);
char choosePowerType(uint32_t& state);
}
