# NEON BREAKER Master 1.16 – čitelný HUD pro Miyoo

## Změny
- Horní lišta nyní zobrazuje číslo levelu, skóre a počet životů jako textové hodnoty.
- Ukazatel postupu levelu vychází ze skutečného `levelScore / levelTarget`, nikoli ze zbytku skóre.
- Zobrazuje aktuální skóre levelu, cílové skóre a procento postupu.
- Při aktivním bossovi se zobrazuje jeho HP a grafický ukazatel.
- Spodní řádek zobrazuje aktivní bonusy a zbývající čas v sekundách; při více míčích jejich počet.
- Přidán samostatný test formátování a výpočtu HUD.

## Ověření
- `test_hud` ověřuje nulový, poloviční a dokončený postup, formát skóre, čas bonusů a multi-ball.
- SDL2 frontend a ARM binárka musí být sestaveny v cílovém toolchainu; běh na Miyoo nebyl proveden.
