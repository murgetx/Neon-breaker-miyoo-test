# NEON BREAKER Master 1.9 – čitelné menu a ovládání gamepadem

## Změny
- Hlavní menu, pauza, konec hry a dokončení hry nyní vykreslují skutečné textové názvy položek přes interní bitmapovou abecedu.
- Vybraná položka je zvýrazněna barevným pruhem a kurzorem.
- Na obrazovkách menu se zobrazuje stručná legenda ovládání.
- SDL gamecontroller D-pad nyní obsluhuje pohyb v menu; tlačítko A potvrzuje výběr.
- Start v průběhu hry pozastaví hru, Start v pauze ji vrátí do hry.
- Pohyb pálky klávesnicí a D-padem je omezen na herní obrazovku; šipky v menu již nemění cílovou pozici pálky.
- Akce obrazovek Konec hry a Level hotov jsou rozdělené podle vybrané položky místo společného automatického restartu.

## Zachováno
- Zdrojové HTML 11.9.9 a původní příběhová data zůstávají beze změny.
- 100 kapitol, šest rozhodnutí kampaně a šest zakončení zůstávají součástí projektu.
- Save formát zůstává verze 6.

## Stav ověření
- Provedena úprava SDL2 frontendu a kontrola změněných větví zdrojového kódu.
- Spuštěné předkompilované hostitelské testovací programy z balíku 1.8 doběhly bez chyb; nejde o nové sestavení těchto testů.
- Kompletní `make test` nebyl v tomto běhu dokončen kvůli časovému limitu prostředí.
- Skutečné SDL2 sestavení, ARM/Miyoo kompilace a test na zařízení stále nejsou provedeny.

Toto je zdrojový milník 1.9, nikoli instalovatelný balíček pro Miyoo.
