# NEON BREAKER Master 1.20 – ARM/CI build pipeline

## Změny
- Přidán reprodukovatelný GitHub Actions workflow pro hostitelské testy a ARM cross-build.
- Přidán `tools/run_tests.sh`, který sestavuje sdílené objektové soubory jednou a spouští všech 16 testovacích programů.
- Přidán `tools/build_miyoo.sh` pro ARMv7 hard-float kompilaci SDL2 frontendu proti Miyoo SDL2 knihovně.
- Přidána kontrola ELF32/ARM, runtime knihovny a základní OnionOS adresářová struktura `Roms/PORTS/Games/NEON_BREAKER`.
- Workflow vytváří artefakt `NEON_BREAKER_Miyoo_OnionOS_ARM.zip` pouze po úspěšném cross-build kroku.

## Důležité limity
- Workflow je připravený, ale nebyl spuštěn na GitHub Actions; proto zatím neexistuje ověřená ARM binárka.
- SDL2 upstream uvádí Miyoo Mini/Plus a OnionOS v4.3.1-1; kompatibilita s Red Onion 4.5.0 musí být potvrzena na zařízení.
- Balíček zatím obsahuje spouštěcí skript v herní složce, nikoli ověřený `.port` shortcut pro Ports Collection. Ten doplníme podle šablony cílové verze OnionOS.
- Fyzický test na Miyoo Mini Plus nebyl proveden.
