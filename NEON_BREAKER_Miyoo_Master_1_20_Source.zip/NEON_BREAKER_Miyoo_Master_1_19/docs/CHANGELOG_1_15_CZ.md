# NEON BREAKER Master 1.15 – stabilizace ovládání Miyoo

## Změny
- Přidána samostatná čistá funkce pro převod osy levé páčky na pozici pálky.
- Zavedená mrtvá zóna 6 000 jednotek omezuje samovolný pohyb pálky při driftu analogové páčky.
- Rozsah osy je bezpečně omezen a převáděn na herní prostor 25–375.
- SDL2 frontend nyní reaguje na připojení a odpojení gamepadu za běhu; při odpojení aktivního ovladače uvolní jeho SDL handle.
- Přidán samostatný test mrtvé zóny, krajních hodnot a směru pohybu.

## Ověření
- `test_input` byl nově zkompilován a spuštěn – PASS.
- Osm již sestavených testů (`campaign`, `session`, `savegame`, `boss_session`, `integrated_powerups`, `drop_balance`, `weapon_and_drops`, `special_physics`) bylo spuštěno – všech 8 PASS.
- `make test` bylo spuštěno, ale běh skončil časovým limitem při kompilaci `test_level_clear`; zbývající testy této sady proto nejsou potvrzené.
- SDL2/ARM sestavení a běh na skutečném Miyoo Mini Plus zůstávají neověřené.

## Omezení
- Mrtvá zóna se týká analogové osy. D-pad zůstává digitální a beze změny.
- Projekt stále používá logickou plochu 400 × 700; skutečné vykreslení a čitelnost na displeji 640 × 480 je nutné ověřit na zařízení.
