# NEON BREAKER Master 1.19 – částicové zásahové efekty

## Změny
- Přidán lehký částicový systém bez externích grafických assetů.
- Zásah bloku vytvoří krátký zlatavý rozptyl částic v místě míčku.
- Zásah bosse vytvoří výraznější červenooranžový rozptyl u středu bosse.
- Částice mají rychlost, gravitaci, postupné zhasínání a omezenou životnost.
- Generování je deterministické pro opakovatelné testy.
- Počet aktivních částic je omezen na 160 kvůli výkonu Miyoo Mini Plus.
- Herní mechaniky, levely, kampaň, skóre a ukládání se nemění.

## Ověření
- `test_effects`: nově zkompilován a spuštěn – PASS.
- `make test`: spuštěno; osm testů dokončilo kompilaci a běh (campaign, session, savegame, boss_session, integrated_powerups, drop_balance, weapon_and_drops, special_physics). Kompilace `test_level_clear` byla ukončena časovým limitem. Zbývající testy tedy nejsou potvrzené.
- SDL2 frontend nebyl zkompilován; v tomto prostředí nejsou dostupné SDL2 vývojové hlavičky/knihovny.
- ARM/Miyoo binárka a běh na fyzickém zařízení nebyly ověřeny.
