# NEON BREAKER Master 1.17 – rozvržení pro Miyoo 640 × 480

## Změny
- Zachována původní herní logická plocha 400 × 700; její poměr stran se nedeformuje.
- Na displeji 640 × 480 zůstává hra ve středovém portrétním viewportu s poměrem stran 4:7 (přibližně 274 × 480 px).
- Volné boční plochy jsou využity jako dva informační panely: název hry, 174 BPM, ovládání, level, skóre, životy a stav/hlasitost zvuku.
- Boční panely se kreslí v nativních souřadnicích displeje a po vykreslení se obnoví logická velikost hry.
- Nedochází k neproporcionálnímu natažení herní plochy ani kruhových objektů.

## Omezení a ověření
- Rozvržení je navrženo pro okno 640 × 480; fyzický běh na Miyoo Mini Plus nebyl proveden.
- SDL2 frontend nebyl v tomto prostředí zkompilován, protože nejsou dostupné SDL2 vývojové hlavičky/knihovny.
- Změna se týká vykreslování; nemění levely, fyziku, příběh ani formát uložené hry.
