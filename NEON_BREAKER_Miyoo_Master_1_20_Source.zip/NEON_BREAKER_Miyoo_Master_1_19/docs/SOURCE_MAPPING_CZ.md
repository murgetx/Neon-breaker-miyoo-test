# Mapování původního zdroje

Tento milník přenáší zdrojová data přímo z HTML v11.9.9: `campaignStory` (100 položek), `bossFunnyNames` (20 jmen) a `endingDecisionMap` (6 rozhodnutí: 29, 45, 59, 76, 83, 92).

`campaign_data.hpp` je kompilovatelná kopie těchto dat. `campaign.cpp` implementuje jednorázové vyhodnocení šesti rozhodnutí a pravidla názvu konce podle původního `resolveEndingTitle`. JSON soubory jsou archivní strojově čitelné kopie.

Moduly levelgen, physics, powerups, special_blocks a bosses jsou sjednoceny pod jedním `GameSession` facadem. Toto je integrační vrstva zdrojového portu; není to ještě SDL2 vykreslovací aplikace ani ARM binárka pro Miyoo.

## Master 1.1 – nové součásti
- `src/main_sdl.cpp`: první SDL2 obrazovková a vstupní vrstva; nejde o úplný převod původního DOM/UI.
- `src/savegame.cpp/.hpp`: verzované textové ukládání a načítání základního běhového stavu.
- `tests/test_savegame.cpp`: round-trip test uložit/načíst.
