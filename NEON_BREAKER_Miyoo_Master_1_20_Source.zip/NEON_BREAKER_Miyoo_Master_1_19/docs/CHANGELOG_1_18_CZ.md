# NEON BREAKER Master 1.18 – čitelnější grafika herní plochy

## Změny
- Bloky nyní používají samostatné barevné palety podle skutečného typu: normal, steel, gold, explosive, regen a moving.
- Barva čelní plochy reaguje na zbývající HP; poškozené bloky jsou vizuálně tmavší.
- Hrany bloků mají kontrastní barvu odpovídající jejich typu.
- Přidán jemný horní odlesk bloků, zvýraznění pálky a kontrastnější míček i multi-ball.
- Herní logika, rozložení levelů, fyzika, kampaň, bossové a ukládání se nemění.
- Přidán samostatný test čistých funkcí barevné palety.

## Ověření
- `test_render_style` ověřuje odlišení typů bloků, reakci na HP a hraniční hodnoty.
- SDL2 frontend a ARM binárka vyžadují cílový toolchain; fyzický běh na Miyoo nebyl proveden.
