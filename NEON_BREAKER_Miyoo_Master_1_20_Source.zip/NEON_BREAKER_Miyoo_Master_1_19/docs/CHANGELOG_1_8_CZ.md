# NEON BREAKER Master 1.8 – příběhová kampaň v SDL2

## Co přibylo
- Příběhová obrazovka je součástí SDL2 frontendu; používá originální `campaign_data.hpp` se 100 kapitolami.
- Po startu kampaně se zobrazí kapitola 1; po vyčištění levelu se zobrazí další kapitola před spuštěním dalšího levelu.
- Text se vykresluje interní 5×7 bitmapovou abecedou, české znaky se pro displej transliterují; zdrojová data zůstávají beze změny.
- D-pad nahoru/dolů posouvá text, vlevo/vpravo přepíná volbu.
- Šest rozhodnutí na levelech 29, 45, 59, 76, 83 a 92 se aplikuje jednou a ovlivňuje hodnoty dealer/radio/trust/evidence/crew/plant/aiControl.
- Příběhové větve se zobrazují od odpovídajících kapitol.
- Po levelu 100 se zobrazí jeden ze šesti konců podle původních pravidel kampaně.
- Ukládání rozhodnutí pokračuje v save formátu verze 6.

## Ovládání příběhu
- D-pad nahoru/dolů: posun textu.
- D-pad vlevo/vpravo: výběr A/B.
- A nebo START: potvrzení / pokračování.
- Klávesnice při desktop testu: šipky, A, Enter nebo mezerník.

## Testy
- Ověřeno: původní testy kampaně, session, bossů a ukládání.
- Přidán `test_campaign_full.cpp`: ověřuje všech šest rozhodnutí, jednorázové použití, větvení a dosažitelné konce.
- `main_sdl.cpp` prošel syntaktickou kontrolou proti SDL2 API stubu; skutečné SDL2 knihovny nejsou v tomto prostředí dostupné.

## Omezení
Tato verze nebyla sestavena proti reálnému SDL2 ani pro ARM/Miyoo. Je to zdrojový milník, ne instalační balíček pro SD kartu.
