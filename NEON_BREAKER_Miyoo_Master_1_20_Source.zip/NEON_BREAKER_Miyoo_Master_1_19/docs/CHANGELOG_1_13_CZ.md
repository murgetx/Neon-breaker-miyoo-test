# NEON BREAKER Master 1.13 – trvalé zvukové preference

## Změny
- Přidán samostatný modul `settings.hpp/.cpp` pro audio preference.
- Hlasitost (0.00–1.00) a zapnutí/vypnutí zvuku se ukládají do `neon_audio.cfg`.
- Při startu SDL2 frontendu se preference načtou; při změně klávesou M, [ / ] nebo L/R se ihned uloží.
- Konfigurační formát je verzovaný (`NEON_AUDIO 1`) a odmítá neznámou verzi, neplatný přepínač, rozsah hlasitosti mimo 0–1 i přebytečná data.
- Zápis používá dočasný soubor a zálohu `.bak`, aby se omezilo riziko poškození konfigurace při přerušení zápisu.
- Přidán samostatný test načtení, uložení, výchozích hodnot a odmítnutí poškozených/nesmyslných dat.

## Ověření
- `test_settings`: zkompilován a spuštěn – PASS.
- Samostatně spuštěné testy: campaign, session, savegame, boss_session, integrated_powerups, drop_balance, weapon_and_drops a special_physics – PASS.
- `make test` nebyl dokončen v limitu běhu; při sestavování/sestavě testů se zastavil u `test_level_clear`. `test_level_clear` a `test_campaign_full` proto nejsou potvrzené.
- SDL2 frontend a ARM/Miyoo binárka nebyly sestaveny; prostředí nemá potvrzenou Miyoo toolchain/SDL2 konfiguraci.
