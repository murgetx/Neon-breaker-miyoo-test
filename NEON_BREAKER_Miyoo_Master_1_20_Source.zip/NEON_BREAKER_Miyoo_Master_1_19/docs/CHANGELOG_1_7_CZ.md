# NEON BREAKER Master 1.7 – změny

## Integrace dokončení levelu
- Přidán původní bodový cíl levelu `250 + level * 12`.
- Při splnění cíle se při vyčištění pole udělí bonus `500 + level * 100`.
- Level se nepovažuje za dokončený, dokud nejsou zničeny všechny bloky a poražen aktivní boss.
- SDL2 frontend nyní přechází dál pouze přes stav `GameSession::cleared()`; dřívější přeskočení živého bosse po zničení bloků je odstraněno.
- `GameSession::story()` poskytuje odpovídající kapitolu z původních 100 příběhových kapitol a `chooseStory()` předává volby do kampaně.
- Ukládací formát zvýšen na verzi 5 a ukládá bodový cíl, bonus a stav dokončení levelu.

## Ověření
- `make test` dokončeno úspěšně, včetně nového testu dokončení levelu a blokování postupu při živém bossovi.
- Kompilace a běh na Miyoo zatím nebyly ověřeny.
