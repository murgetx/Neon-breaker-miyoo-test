# NEON BREAKER Master 1.10 – bezpečnější ukládání

## Změny
- Uložení se nejprve zapisuje do dočasného souboru `<save>.tmp` a před výměnou se kontroluje úspěšnost zápisu.
- Předchozí platná generace se uchovává jako `<save>.bak`.
- Pokud výměna dočasného souboru selže, původní soubor se obnoví.
- Před zápisem se odmítne neplatný stav hry: mimo rozsah level/životy nebo nečíselné hodnoty míčku či pálky.
- Rozšířen test ukládání o kontrolu záložní kopie, odmítnutí NaN a zachování posledního platného save.

## Kompatibilita
- Formát uložené pozice zůstává `NEON_BREAKER_SAVE 6`; starší save verze 6 není nutné převádět.
- Cílová cesta zůstává `neon_breaker.sav`; záloha bude `neon_breaker.sav.bak`.

## Ověření
- Samostatný test `test_savegame` byl znovu zkompilován a úspěšně spuštěn.
- Kompletní `make test` byl spuštěn, ale běh byl ukončen časovým limitem prostředí; nelze tedy potvrdit průchod celé sady.
- SDL2/ARM kompilace a test na Miyoo stále nejsou provedeny.
