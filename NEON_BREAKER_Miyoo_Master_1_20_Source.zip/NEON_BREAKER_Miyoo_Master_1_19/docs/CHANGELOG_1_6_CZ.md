# Změny Master 1.6

- Speciální bloky používají stejnou strukturu `Brick` jako generátor levelů a fyzika.
- Fyzikální kolize nyní volá společný resolver zásahů.
- Ocelový blok zůstává nezničitelný a pouze odrazí míček.
- Zlatý blok uděluje 100 bodů.
- Výbušný blok poškodí sousední neocelové bloky v definovaném dosahu; řetězové zničení vrací souřadnice všech zasažených bloků.
- Regenerační blok obnovuje život po 300 jednotkách časovače.
- Pohyblivý blok osciluje v rozsahu ±3,5 px.
- Herní smyčka aktualizuje speciální bloky každý snímek.
- Přidán regresní test fyzikální integrace speciálních bloků.

Poznámka: Původní generátor stále vytváří standardní bloky. Speciální typy jsou integrovány a připraveny pro přesné přiřazení do levelů, ale nejsou náhodně přidávány do původních formací.
