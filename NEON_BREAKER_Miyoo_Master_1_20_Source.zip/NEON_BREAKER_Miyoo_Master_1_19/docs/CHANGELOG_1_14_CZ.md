# NEON BREAKER Master 1.14 – obrazovka nastavení zvuku

## Změny
- Do hlavního menu přidána samostatná položka `NASTAVENI ZVUKU`.
- Nová obrazovka zobrazuje stav zvuku a aktuální hlasitost v procentech.
- Nastavení lze měnit klávesnicí i gamepadem: nahoru/dolů vybírá položku, vlevo/vpravo mění hodnotu, A přepíná zvuk a položka ZPĚT vrací do hlavního menu.
- START/ESC vrací z nastavení do hlavního menu.
- Každá změna se ihned ukládá přes stávající verzovaný modul `settings.cpp` do `neon_audio.cfg`.
- Hlavní menu má nyní pět položek; ostatní nabídky si zachovávají čtyři položky.
- Zachováno rychlé ovládání M a [ / ] i gamepadovými L/R tlačítky.

## Ověření
- `test_campaign`, `test_session`, `test_savegame`, `test_boss_session`, `test_integrated_powerups`, `test_drop_balance`, `test_weapon_and_drops`, `test_special_physics`, `test_level_clear`, `test_campaign_full`, `test_audio_engine` a `test_settings` byly zkompilovány/spuštěny; všechny skončily úspěšně.
- Kompletní `make test` byl přerušen časovým limitem při sestavování `test_level_clear`; tento test a následující testy byly proto následně sestaveny/spuštěny samostatně a prošly.
- SDL2 frontend nebylo možné v tomto prostředí zkompilovat: chybí SDL2 vývojové hlavičky (`SDL.h`).
- ARM/Miyoo binárka a běh na skutečném Miyoo Mini Plus nejsou ověřené.

## Známé limity
- Nová obrazovka nastavení je implementována ve zdrojovém SDL2 frontendu, ale bez SDL2 toolchainu zde nelze potvrdit její běh ani vizuální rozložení na Miyoo.
- Zvukové preference zůstávají oddělené od herní pozice.
