# NEON BREAKER Master 1.12 – propojení zvukových událostí

## Změny
- Zvuk poškození bloku je napojen na výsledek fyzikálního kroku.
- Zvuk pálky se spouští při obratu vertikální rychlosti míče směrem vzhůru.
- Sebrání power-upu spouští samostatný zvukový efekt.
- Zásah bosse vyvolá úderový efekt.
- Hlasitost lze vedle kláves [ a ] měnit také tlačítky L/R na gamepadu.
- Zachována původní audio smyčka 174 BPM a stávající API audio enginu.

## Omezení a ověření
- Jde o integraci událostí do SDL2 frontendu; bez SDL2 vývojových knihoven nelze frontend v tomto prostředí sestavit.
- Zvukový engine a jeho samostatný test jsou oddělené od SDL2 a lze je ověřit lokálním testem.
- Tlačítka L/R závisejí na mapování SDL gamecontroller daného firmware Miyoo.
- Hlasitost zatím není ukládána do save souboru.
