# NEON BREAKER Master 1.11 – procedurální audio

## Změny
- Přidán samostatný lehký audio engine v `src/audio_engine.*`; nevyžaduje SDL_mixer ani externí hudební soubory.
- SDL2 frontend otevírá stereo výstup 22 050 Hz / signed 16-bit a generuje zvuk v callbacku.
- Procedurální rytmická smyčka v tempu 174 BPM kombinuje basový puls, kopák, backbeat a šumové hi-hat prvky.
- Připraveny zvukové obálky pro úder pálky, zničení bloku a sebrání bonusu; herní události zatím nejsou ve všech místech napojené.
- Klávesa M zapíná/vypíná zvuk; [ a ] mění hlasitost po 5 %.
- Přidán samostatný test generování zvuku, mute a rozsahu hlasitosti.

## Ověření
- Test audio engine byl zkompilován a prošel.
- Devět dostupných původních testovacích binárek prošlo samostatným spuštěním; desátý test kampaně byl nově zkompilován a také prošel.
- Kompletní `make test` se v limitu prostředí přerušil, proto není označen jako plně dokončený běh.
- V prostředí není dostupný SDL2 vývojový balíček (`sdl2-config`/pkg-config), takže frontend a ARM cíl nešlo zkompilovat.

## Omezení
- Jde o procedurální pracovní soundtrack, nikoli o finální studiovou DnB skladbu.
- Zvukové efekty jsou připravené jako API, ale zatím nejsou propojené se všemi kolizemi a power-up událostmi.
- Ovládání zvuku gamepadem a nabídka nastavení ještě nejsou doplněné.
- SDL2/ARM kompilace ani test na skutečném Miyoo nebyly provedeny.

## Navazující integrace – Master 1.12
- SDL2 frontend nyní spouští zvuk úderu při poškození cihel.
- Zvuk pálky se spouští při změně směru míče směrem vzhůru po kontaktu ve spodní části hřiště.
- Sebrání padajícího bonusu vyvolá zvuk power-upu.
- Zásah bosse spouští úderový efekt.
- Hlasitost lze měnit také tlačítky L/R ramenními tlačítky gamepadu po 5 %.
- Tyto změny jsou zatím zdrojově integrovány; SDL2 frontend nebyl v tomto prostředí zkompilován kvůli chybějícím SDL2 vývojovým knihovnám.
